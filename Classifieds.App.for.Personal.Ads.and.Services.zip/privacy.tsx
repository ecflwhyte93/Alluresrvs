import { useRouter } from "expo-router";
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { IconSymbol } from "@/components/ui/icon-symbol";

const SECTIONS = [
  {
    title: "Information We Collect",
    body: "We collect information you provide directly, including your display name, age, location, profile photos, listing content, and messages. We also collect usage data such as app interactions, device type, and IP address to improve the service.",
  },
  {
    title: "How We Use Your Information",
    body: "We use your information to operate and improve Allure, display your listings to other users, facilitate messaging between users, process payments, send notifications, and enforce our Terms of Service. We do not sell your personal data to third parties.",
  },
  {
    title: "Photo Verification",
    body: "If you choose to verify your account, you will submit a selfie and a government-issued ID. This information is used solely for identity verification. ID documents are reviewed by our team and deleted within 72 hours of verification completion. Selfies may be retained as part of your verified status record.",
  },
  {
    title: "Payment Information",
    body: "All payment processing is handled by Stripe, a PCI-compliant payment processor. Allure does not store your full credit card number or CVV. We retain transaction records (amount, date, plan type) for billing and dispute resolution purposes.",
  },
  {
    title: "Data Sharing",
    body: "We share data with Stripe for payment processing, and may share data with law enforcement when required by law. We do not share your personal information with advertisers or data brokers. Your public listing information (photos, description, location) is visible to all app users.",
  },
  {
    title: "Data Retention",
    body: "Active account data is retained while your account is active. Deleted listings are removed from public view immediately but may be retained in our systems for up to 30 days for safety and legal compliance. You may request deletion of your account and associated data at any time.",
  },
  {
    title: "Cookies & Tracking",
    body: "We use analytics tools to understand how users interact with the app. This data is aggregated and anonymized. We do not use third-party advertising trackers.",
  },
  {
    title: "Your Rights",
    body: "You have the right to access, correct, or delete your personal data. You may also opt out of non-essential communications. To exercise these rights, contact us at privacy@allure.app. We will respond within 30 days.",
  },
  {
    title: "Security",
    body: "We use industry-standard encryption and security practices to protect your data. However, no system is completely secure. Please use a strong password and do not share your account credentials with others.",
  },
  {
    title: "Children's Privacy",
    body: "Allure is strictly for users 18 years of age and older. We do not knowingly collect data from minors. If we discover that a minor has created an account, we will immediately terminate it and delete all associated data.",
  },
  {
    title: "Changes to This Policy",
    body: "We may update this Privacy Policy periodically. We will notify you of material changes via in-app notification. Continued use of Allure after changes constitutes acceptance of the updated policy.",
  },
];

export default function PrivacyScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <IconSymbol name="chevron.left" size={20} color="#F5F0F0" />
        </Pressable>
        <Text style={styles.title}>Privacy Policy</Text>
        <View style={{ width: 36 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <View style={styles.banner}>
          <Text style={styles.bannerIcon}>🔒</Text>
          <Text style={styles.bannerTitle}>Your Privacy Matters</Text>
          <Text style={styles.bannerDate}>Effective: January 1, 2025</Text>
        </View>

        <Text style={styles.intro}>
          This Privacy Policy explains how Allure collects, uses, and protects your personal information. We are committed to transparency and your right to privacy.
        </Text>

        {SECTIONS.map((section) => (
          <View key={section.title} style={styles.section}>
            <Text style={styles.sectionTitle}>{section.title}</Text>
            <Text style={styles.sectionBody}>{section.body}</Text>
          </View>
        ))}

        <View style={styles.footer}>
          <Text style={styles.footerText}>
            Questions? Contact us at privacy@allure.app{"\n"}
            We respond within 30 business days.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0A0A0A" },
  header: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 20, paddingVertical: 14,
    borderBottomWidth: 1, borderBottomColor: "#1A1A1A",
  },
  backBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: "#161618", alignItems: "center", justifyContent: "center",
  },
  title: { color: "#F5F0F0", fontSize: 17, fontWeight: "800" },
  content: { padding: 20, gap: 20, paddingBottom: 60 },
  banner: {
    alignItems: "center", backgroundColor: "#161618",
    borderRadius: 16, padding: 20, gap: 6,
    borderWidth: 1, borderColor: "#2A1F1F",
  },
  bannerIcon: { fontSize: 32 },
  bannerTitle: { color: "#F5F0F0", fontSize: 18, fontWeight: "800" },
  bannerDate: { color: "#7A6F6F", fontSize: 12 },
  intro: { color: "#C5B8B8", fontSize: 14, lineHeight: 22 },
  section: { gap: 8 },
  sectionTitle: { color: "#D42B2B", fontSize: 15, fontWeight: "700" },
  sectionBody: { color: "#C5B8B8", fontSize: 13, lineHeight: 21 },
  footer: {
    backgroundColor: "#161618", borderRadius: 12, padding: 16,
    borderWidth: 1, borderColor: "#2A1F1F",
  },
  footerText: { color: "#7A6F6F", fontSize: 12, textAlign: "center", lineHeight: 20 },
});
