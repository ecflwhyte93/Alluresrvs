import AsyncStorage from "@react-native-async-storage/async-storage";
import { useRouter } from "expo-router";
import { useEffect, useState } from "react";
import {
  FlatList,
  Image,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useAppStore } from "@/lib/store";

type AppNotification = {
  id: string;
  type: "message" | "match" | "expiry" | "review" | "system";
  title: string;
  body: string;
  timestamp: string;
  isRead: boolean;
  avatar?: string;
  actionRoute?: string;
  actionParams?: Record<string, string>;
};

const STORAGE_KEY = "allure_notifications";

const TYPE_ICON: Record<AppNotification["type"], string> = {
  message: "💬",
  match: "❤️",
  expiry: "⏱",
  review: "⭐",
  system: "🔔",
};

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "Just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

export default function NotificationsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { state } = useAppStore();
  const [notifications, setNotifications] = useState<AppNotification[]>([]);

  useEffect(() => {
    // Load stored notifications
    AsyncStorage.getItem(STORAGE_KEY).then((val) => {
      const stored: AppNotification[] = val ? JSON.parse(val) : [];

      // Generate notifications from app state
      const generated: AppNotification[] = [];

      // Unread messages
      state.conversations
        .filter((c) => c.unreadCount > 0)
        .forEach((c) => {
          const lastMsg = c.messages[c.messages.length - 1];
          if (lastMsg && lastMsg.senderId !== "me") {
            generated.push({
              id: `msg_${c.id}`,
              type: "message",
              title: `New message from ${c.participantName}`,
              body: lastMsg.text.length > 60 ? lastMsg.text.slice(0, 60) + "…" : lastMsg.text,
              timestamp: lastMsg.timestamp,
              isRead: false,
              avatar: c.participantAvatar,
              actionRoute: "/chat/[id]",
              actionParams: { id: c.id },
            });
          }
        });

      // Expiring listings
      state.listings
        .filter((l) => l.userId === "me" && !l.isDeleted)
        .forEach((l) => {
          const msLeft = new Date(l.expiresAt).getTime() - Date.now();
          if (msLeft > 0 && msLeft < 2 * 3600000) {
            generated.push({
              id: `expiry_${l.id}`,
              type: "expiry",
              title: "Ad expiring soon!",
              body: `"${l.title}" expires in less than 2 hours. Renew now to keep it live.`,
              timestamp: new Date().toISOString(),
              isRead: false,
              actionRoute: "/paywall",
            });
          }
        });

      // Reviews received
      state.profile.reviews.slice(0, 2).forEach((r) => {
        generated.push({
          id: `review_${r.id}`,
          type: "review",
          title: `${r.fromUserName} left you a review`,
          body: `${"★".repeat(r.rating)}${"☆".repeat(5 - r.rating)} — "${r.comment}"`,
          timestamp: r.date,
          isRead: true,
          avatar: r.fromUserAvatar,
          actionRoute: "/(tabs)/profile",
        });
      });

      // Welcome notification
      generated.push({
        id: "welcome",
        type: "system",
        title: "Welcome to Allure ✦",
        body: "Complete your photo verification to get a verified badge and boost your listings.",
        timestamp: state.profile.memberSince,
        isRead: true,
        actionRoute: "/verify",
      });

      // Merge generated with stored (avoid duplicates)
      const existingIds = new Set(stored.map((n) => n.id));
      const merged = [
        ...generated.filter((n) => !existingIds.has(n.id)),
        ...stored,
      ].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

      setNotifications(merged);
      AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
    });
  }, []);

  const markAllRead = () => {
    const updated = notifications.map((n) => ({ ...n, isRead: true }));
    setNotifications(updated);
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  };

  const handleTap = (notif: AppNotification) => {
    // Mark as read
    const updated = notifications.map((n) => n.id === notif.id ? { ...n, isRead: true } : n);
    setNotifications(updated);
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updated));

    if (notif.actionRoute) {
      if (notif.actionParams) {
        router.push({ pathname: notif.actionRoute as any, params: notif.actionParams });
      } else {
        router.push(notif.actionRoute as any);
      }
    }
  };

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <IconSymbol name="chevron.left" size={20} color="#F5F0F0" />
        </Pressable>
        <View>
          <Text style={styles.title}>Notifications</Text>
          {unreadCount > 0 && (
            <Text style={styles.unreadCount}>{unreadCount} unread</Text>
          )}
        </View>
        {unreadCount > 0 && (
          <Pressable onPress={markAllRead}>
            <Text style={styles.markAllText}>Mark all read</Text>
          </Pressable>
        )}
      </View>

      <FlatList
        data={notifications}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyIcon}>🔔</Text>
            <Text style={styles.emptyText}>No notifications yet</Text>
            <Text style={styles.emptySubtext}>We'll let you know when something happens</Text>
          </View>
        }
        renderItem={({ item }) => (
          <Pressable
            onPress={() => handleTap(item)}
            style={({ pressed }) => [
              styles.notifCard,
              !item.isRead && styles.notifCardUnread,
              pressed && { opacity: 0.8 },
            ]}
          >
            <View style={styles.notifIconWrap}>
              {item.avatar ? (
                <Image source={{ uri: item.avatar }} style={styles.notifAvatar} />
              ) : (
                <View style={styles.notifIconCircle}>
                  <Text style={styles.notifTypeIcon}>{TYPE_ICON[item.type]}</Text>
                </View>
              )}
              {!item.isRead && <View style={styles.unreadDot} />}
            </View>
            <View style={styles.notifBody}>
              <Text style={styles.notifTitle} numberOfLines={1}>{item.title}</Text>
              <Text style={styles.notifText} numberOfLines={2}>{item.body}</Text>
              <Text style={styles.notifTime}>{timeAgo(item.timestamp)}</Text>
            </View>
            <IconSymbol name="chevron.right" size={14} color="#3A2A2A" />
          </Pressable>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0A0A0A" },
  header: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 20, paddingVertical: 14,
    borderBottomWidth: 1, borderBottomColor: "#1A1A1A",
  },
  backBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: "#161618", alignItems: "center", justifyContent: "center",
  },
  title: { color: "#F5F0F0", fontSize: 18, fontWeight: "800" },
  unreadCount: { color: "#D42B2B", fontSize: 11, fontWeight: "700", marginTop: 1 },
  markAllText: { color: "#D42B2B", fontSize: 13, fontWeight: "700" },
  list: { padding: 16, gap: 8, paddingBottom: 80 },
  notifCard: {
    flexDirection: "row", alignItems: "center", gap: 12,
    backgroundColor: "#161618", borderRadius: 14,
    padding: 14, borderWidth: 1, borderColor: "#2A1F1F",
  },
  notifCardUnread: { borderColor: "#3A1A1A", backgroundColor: "#1A1010" },
  notifIconWrap: { position: "relative" },
  notifAvatar: { width: 46, height: 46, borderRadius: 23 },
  notifIconCircle: {
    width: 46, height: 46, borderRadius: 23,
    backgroundColor: "#2A1A1A", alignItems: "center", justifyContent: "center",
  },
  notifTypeIcon: { fontSize: 22 },
  unreadDot: {
    position: "absolute", top: 0, right: 0,
    width: 10, height: 10, borderRadius: 5, backgroundColor: "#D42B2B",
    borderWidth: 2, borderColor: "#0A0A0A",
  },
  notifBody: { flex: 1 },
  notifTitle: { color: "#F5F0F0", fontSize: 13, fontWeight: "700", lineHeight: 18 },
  notifText: { color: "#9A8F8F", fontSize: 12, lineHeight: 17, marginTop: 2 },
  notifTime: { color: "#5A4F4F", fontSize: 11, marginTop: 4 },
  empty: { alignItems: "center", paddingTop: 80, gap: 10 },
  emptyIcon: { fontSize: 48 },
  emptyText: { color: "#F5F0F0", fontSize: 18, fontWeight: "700" },
  emptySubtext: { color: "#7A6F6F", fontSize: 13, textAlign: "center" },
});
