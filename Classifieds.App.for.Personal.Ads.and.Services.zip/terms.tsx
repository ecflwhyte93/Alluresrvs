import { useRouter } from "expo-router";
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { IconSymbol } from "@/components/ui/icon-symbol";

const SECTIONS = [
  {
    title: "1. Eligibility",
    body: "You must be at least 18 years of age to use Allure. By accessing or using the app, you represent and warrant that you are 18 or older. We reserve the right to terminate accounts of users who misrepresent their age.",
  },
  {
    title: "2. Adult Content Policy",
    body: "Allure is an adult-oriented social classifieds platform. Users may post content of a mature nature, including content related to dating, companionship, and adult services. All content must comply with applicable laws. Illegal content, including anything involving minors, is strictly prohibited and will be reported to law enforcement.",
  },
  {
    title: "3. User Conduct",
    body: "You agree not to harass, threaten, or harm other users. You must not post false, misleading, or fraudulent listings. Spam, scams, and impersonation are prohibited. Allure reserves the right to remove any content and suspend or terminate accounts that violate these terms.",
  },
  {
    title: "4. Payments & Subscriptions",
    body: "Posting fees are charged at $5.99 per single post (active for 24 hours), $10.99 per week, or $29.99 per month. All payments are processed securely via Stripe. Subscriptions auto-renew unless cancelled. Refunds are not provided for unused posting time.",
  },
  {
    title: "5. Post Expiry & Removal",
    body: "Single posts expire after 24 hours. Weekly and monthly subscriptions allow unlimited posts for the subscription duration. Allure reserves the right to remove any listing that violates these Terms at any time without refund.",
  },
  {
    title: "6. Verification",
    body: "Photo verification is voluntary but recommended. Verified status is awarded after submitting a selfie and government-issued ID. Allure does not store ID documents beyond the verification review period. Verification does not guarantee the accuracy of any user's claims.",
  },
  {
    title: "7. Ratings & Reviews",
    body: "The mutual rating system is provided for safety and transparency. Users may rate each other after completing a conversation. Ratings must be honest and based on real interactions. Abuse of the rating system may result in account suspension.",
  },
  {
    title: "8. Privacy",
    body: "Your privacy is important to us. Please review our Privacy Policy to understand how we collect, use, and protect your personal information. By using Allure, you consent to our data practices as described in the Privacy Policy.",
  },
  {
    title: "9. Limitation of Liability",
    body: "Allure is a platform that connects users. We are not responsible for the actions, content, or conduct of any user. We do not verify the identity of users beyond the optional photo verification program. Use this platform at your own risk and always exercise caution when meeting people in person.",
  },
  {
    title: "10. Changes to Terms",
    body: "We may update these Terms of Service from time to time. Continued use of Allure after changes constitutes your acceptance of the new terms. We will notify users of significant changes via in-app notification.",
  },
];

export default function TermsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <IconSymbol name="chevron.left" size={20} color="#F5F0F0" />
        </Pressable>
        <Text style={styles.title}>Terms of Service</Text>
        <View style={{ width: 36 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <View style={styles.banner}>
          <Text style={styles.bannerIcon}>⚖️</Text>
          <Text style={styles.bannerTitle}>Allure Terms of Service</Text>
          <Text style={styles.bannerDate}>Effective: January 1, 2025</Text>
        </View>

        <Text style={styles.intro}>
          By using Allure, you agree to these Terms of Service. Please read them carefully. This is an adult platform — you must be 18 or older to use this app.
        </Text>

        {SECTIONS.map((section) => (
          <View key={section.title} style={styles.section}>
            <Text style={styles.sectionTitle}>{section.title}</Text>
            <Text style={styles.sectionBody}>{section.body}</Text>
          </View>
        ))}

        <View style={styles.footer}>
          <Text style={styles.footerText}>
            For questions about these terms, contact us at legal@allure.app
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0A0A0A" },
  header: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 20, paddingVertical: 14,
    borderBottomWidth: 1, borderBottomColor: "#1A1A1A",
  },
  backBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: "#161618", alignItems: "center", justifyContent: "center",
  },
  title: { color: "#F5F0F0", fontSize: 17, fontWeight: "800" },
  content: { padding: 20, gap: 20, paddingBottom: 60 },
  banner: {
    alignItems: "center", backgroundColor: "#161618",
    borderRadius: 16, padding: 20, gap: 6,
    borderWidth: 1, borderColor: "#2A1F1F",
  },
  bannerIcon: { fontSize: 32 },
  bannerTitle: { color: "#F5F0F0", fontSize: 18, fontWeight: "800" },
  bannerDate: { color: "#7A6F6F", fontSize: 12 },
  intro: { color: "#C5B8B8", fontSize: 14, lineHeight: 22 },
  section: { gap: 8 },
  sectionTitle: { color: "#D42B2B", fontSize: 15, fontWeight: "700" },
  sectionBody: { color: "#C5B8B8", fontSize: 13, lineHeight: 21 },
  footer: {
    backgroundColor: "#161618", borderRadius: 12, padding: 16,
    borderWidth: 1, borderColor: "#2A1F1F",
  },
  footerText: { color: "#7A6F6F", fontSize: 12, textAlign: "center", lineHeight: 18 },
});
