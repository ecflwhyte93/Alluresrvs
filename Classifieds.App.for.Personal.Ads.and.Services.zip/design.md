# Scarlett — Design Plan

## Brand Identity
- **Name**: Scarlett (placeholder — awaiting user confirmation)
- **Tagline**: "Meet. Connect. Ignite."
- **Audience**: Men seeking hookups, dates, and adult companionship
- **Tone**: Dark, seductive, bold, premium, discreet

## Color Palette (Dark-First, Black & Red)
| Token      | Dark Value  | Light Value | Purpose                          |
|------------|-------------|-------------|----------------------------------|
| background | #0A0A0A     | #0A0A0A     | Deep black screen background     |
| surface    | #161618     | #1A1A1C     | Cards, modals, inputs            |
| primary    | #D42B2B     | #C01E1E     | Crimson red — CTAs, highlights   |
| foreground | #F5F0F0     | #F5F0F0     | Primary text                     |
| muted      | #7A6F6F     | #7A6F6F     | Secondary text, placeholders     |
| border     | #2A1F1F     | #2A1F1F     | Dividers, card borders           |
| error      | #FF4444     | #FF4444     | Errors, delete                   |
| success    | #4CAF82     | #4CAF82     | Online status, success           |
| tint       | #D42B2B     | #D42B2B     | Tab bar active tint              |

## Screen List
1. **Explore (Home)** — Browsable feed of listings with category filters
2. **Listing Detail** — Full listing view with photos, description, contact CTA
3. **Post Listing** — Multi-step form to create a new listing (monetized)
4. **Messages** — Inbox of conversations
5. **Chat** — Individual conversation thread
6. **Profile** — User's own profile with their listings
7. **Settings** — App preferences, account info
8. **Paywall / Monetization** — Post pricing & subscription plans

## Monetization Model
| Plan              | Price    | Description                          |
|-------------------|----------|--------------------------------------|
| Single Post       | $5.99    | One-time post, listed for 30 days    |
| Weekly Pass       | $10.99   | Unlimited posts for 7 days           |
| Monthly Pass      | $29.99   | Unlimited posts for 30 days          |

## Navigation Structure
- **Bottom Tab Bar** (4 tabs):
  - Explore (flame/home icon)
  - Post (plus icon — center, red highlighted)
  - Messages (chat bubble icon)
  - Profile (person icon)

## Key User Flows

### Browse & Contact
Explore → tap listing card → Listing Detail → tap "Message" → Chat

### Post a Listing (Monetized)
Explore → tap FAB (+) → Post Listing form → Preview → Paywall (choose plan) → Publish

### Subscription
Profile → "Go Premium" → Subscription screen → select plan → confirm

## Design Principles
- Pure black background (#0A0A0A) — no grays, maximum contrast
- Crimson red (#D42B2B) as the signature accent — buttons, badges, active states
- Seductive photography-forward cards with gradient overlays
- Rounded corners (12–16px) on cards and inputs
- Minimal chrome — content-first, full-bleed images
- iOS HIG compliant: 44pt tap targets, safe area aware
- Subtle red glow effects on featured/premium listings
