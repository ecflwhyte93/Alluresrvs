// ─── Types ────────────────────────────────────────────────────────────────────

export type Category = "All" | "Dating" | "Hookups" | "Companionship" | "Events" | "Other";

export interface Review {
  id: string;
  fromUserId: string;
  fromUserName: string;
  fromUserAvatar: string;
  toUserId: string;
  rating: number; // 1–5
  comment: string;
  date: string; // ISO
}

export interface UserProfile {
  id: string;
  displayName: string;
  bio: string;
  location: string;
  age: number;
  avatar: string;
  memberSince: string; // ISO
  isOnline: boolean;
  isVerified: boolean;
  averageRating: number;
  reviewCount: number;
  reviews: Review[];
  favoriteIds: string[];
  subscriptionPlan: "none" | "weekly" | "monthly";
  subscriptionExpiry: string | null;
  verificationStatus: "none" | "pending" | "verified";
  verificationSelfie?: string;
  verificationId?: string;
}

export interface Listing {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  userRating: number;
  userReviewCount: number;
  userVerified: boolean;
  title: string;
  description: string;
  category: Category;
  photos: string[];
  location: string;
  age: number;
  tags: string[];
  isOnline: boolean;
  isFeatured: boolean;
  createdAt: string; // ISO
  expiresAt: string; // ISO
  isDeleted?: boolean;
  planType?: "single" | "weekly" | "monthly";
}

export interface Message {
  id: string;
  senderId: string;
  text: string;
  timestamp: string; // ISO
}

export interface Conversation {
  id: string;
  participantId: string;
  participantName: string;
  participantAvatar: string;
  listingId: string;
  listingTitle: string;
  messages: Message[];
  unreadCount: number;
  lastMessageAt: string; // ISO
  isCompleted: boolean;
  myRatingGiven: boolean;
}

// ─── Mock Photos (Unsplash placeholder URLs) ─────────────────────────────────

const PHOTOS = {
  f1: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=600&q=80",
  f2: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=600&q=80",
  f3: "https://images.unsplash.com/photo-1488716820095-cbe80883c496?w=600&q=80",
  f4: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=600&q=80",
  f5: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=600&q=80",
  f6: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=600&q=80",
  f7: "https://images.unsplash.com/photo-1546961342-ea5f62d5a27b?w=600&q=80",
  f8: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&q=80",
};

// ─── Mock Listings ────────────────────────────────────────────────────────────

export const MOCK_LISTINGS: Listing[] = [
  {
    id: "l1",
    userId: "u2",
    userName: "Sophia",
    userAvatar: PHOTOS.f1,
    userRating: 4.8,
    userReviewCount: 34,
    userVerified: true,
    title: "Looking for a genuine connection",
    description: "Sophisticated, fun, and open-minded. I enjoy fine dining, late-night conversations, and making memories. Looking for someone who knows what they want.",
    category: "Dating",
    photos: [PHOTOS.f1, PHOTOS.f3],
    location: "Miami, FL",
    age: 26,
    tags: ["Dinner dates", "Travel", "Nightlife"],
    isOnline: true,
    isFeatured: true,
    createdAt: new Date(Date.now() - 86400000).toISOString(),
    expiresAt: new Date(Date.now() + 86400000 * 29).toISOString(),
  },
  {
    id: "l2",
    userId: "u3",
    userName: "Valentina",
    userAvatar: PHOTOS.f2,
    userRating: 4.5,
    userReviewCount: 19,
    userVerified: true,
    title: "Your perfect evening companion",
    description: "Elegant, witty, and full of life. Whether it's a cocktail party, a quiet evening in, or an adventure — I'm your girl. Discretion guaranteed.",
    category: "Companionship",
    photos: [PHOTOS.f2, PHOTOS.f5],
    location: "New York, NY",
    age: 24,
    tags: ["Companionship", "Events", "Discreet"],
    isOnline: true,
    isFeatured: false,
    createdAt: new Date(Date.now() - 172800000).toISOString(),
    expiresAt: new Date(Date.now() + 86400000 * 27).toISOString(),
  },
  {
    id: "l3",
    userId: "u4",
    userName: "Jade",
    userAvatar: PHOTOS.f3,
    userRating: 4.9,
    userReviewCount: 52,
    userVerified: true,
    title: "Passionate & adventurous",
    description: "Life is short — let's make it exciting. I'm spontaneous, passionate, and love meeting new people. No strings, just good vibes and great times.",
    category: "Hookups",
    photos: [PHOTOS.f3, PHOTOS.f6],
    location: "Los Angeles, CA",
    age: 23,
    tags: ["Spontaneous", "No strings", "Fun"],
    isOnline: false,
    isFeatured: true,
    createdAt: new Date(Date.now() - 259200000).toISOString(),
    expiresAt: new Date(Date.now() + 86400000 * 25).toISOString(),
  },
  {
    id: "l4",
    userId: "u5",
    userName: "Celeste",
    userAvatar: PHOTOS.f4,
    userRating: 4.3,
    userReviewCount: 11,
    userVerified: false,
    title: "Let's paint the town red",
    description: "Social butterfly looking for a charming gentleman to explore the city with. I love art galleries, rooftop bars, and deep conversations under the stars.",
    category: "Dating",
    photos: [PHOTOS.f4],
    location: "Chicago, IL",
    age: 28,
    tags: ["Art", "Rooftops", "Conversation"],
    isOnline: true,
    isFeatured: false,
    createdAt: new Date(Date.now() - 345600000).toISOString(),
    expiresAt: new Date(Date.now() + 86400000 * 20).toISOString(),
  },
  {
    id: "l5",
    userId: "u6",
    userName: "Roxanne",
    userAvatar: PHOTOS.f5,
    userRating: 4.7,
    userReviewCount: 28,
    userVerified: true,
    title: "Private events & upscale company",
    description: "Refined, educated, and discreet. Available for private dinners, corporate events, and weekend getaways. References available upon request.",
    category: "Events",
    photos: [PHOTOS.f5, PHOTOS.f7],
    location: "Las Vegas, NV",
    age: 27,
    tags: ["Events", "Travel", "Upscale"],
    isOnline: false,
    isFeatured: false,
    createdAt: new Date(Date.now() - 432000000).toISOString(),
    expiresAt: new Date(Date.now() + 86400000 * 18).toISOString(),
  },
  {
    id: "l6",
    userId: "u7",
    userName: "Mia",
    userAvatar: PHOTOS.f6,
    userRating: 4.6,
    userReviewCount: 41,
    userVerified: true,
    title: "Sweet, spicy, and unforgettable",
    description: "They say first impressions last forever — make yours count. I'm warm, playful, and genuinely enjoy connecting with interesting men.",
    category: "Companionship",
    photos: [PHOTOS.f6, PHOTOS.f8],
    location: "Houston, TX",
    age: 25,
    tags: ["Warm", "Playful", "Genuine"],
    isOnline: true,
    isFeatured: false,
    createdAt: new Date(Date.now() - 518400000).toISOString(),
    expiresAt: new Date(Date.now() + 86400000 * 15).toISOString(),
  },
];

// ─── Mock Conversations ───────────────────────────────────────────────────────

export const MOCK_CONVERSATIONS: Conversation[] = [
  {
    id: "c1",
    participantId: "u2",
    participantName: "Sophia",
    participantAvatar: PHOTOS.f1,
    listingId: "l1",
    listingTitle: "Looking for a genuine connection",
    messages: [
      { id: "m1", senderId: "u2", text: "Hey! Thanks for reaching out 😊", timestamp: new Date(Date.now() - 3600000).toISOString() },
      { id: "m2", senderId: "me", text: "Hi Sophia, your profile caught my eye. Would love to chat more.", timestamp: new Date(Date.now() - 3000000).toISOString() },
      { id: "m3", senderId: "u2", text: "I'd love that! What are you looking for?", timestamp: new Date(Date.now() - 1800000).toISOString() },
    ],
    unreadCount: 1,
    lastMessageAt: new Date(Date.now() - 1800000).toISOString(),
    isCompleted: false,
    myRatingGiven: false,
  },
  {
    id: "c2",
    participantId: "u3",
    participantName: "Valentina",
    participantAvatar: PHOTOS.f2,
    listingId: "l2",
    listingTitle: "Your perfect evening companion",
    messages: [
      { id: "m4", senderId: "me", text: "Hello Valentina, are you available this weekend?", timestamp: new Date(Date.now() - 86400000).toISOString() },
      { id: "m5", senderId: "u3", text: "Hi! Yes, I have Saturday evening free.", timestamp: new Date(Date.now() - 82800000).toISOString() },
    ],
    unreadCount: 0,
    lastMessageAt: new Date(Date.now() - 82800000).toISOString(),
    isCompleted: true,
    myRatingGiven: false,
  },
];

// ─── Mock My Profile ──────────────────────────────────────────────────────────

export const MOCK_MY_PROFILE: UserProfile = {
  id: "me",
  displayName: "Alex",
  bio: "Adventurous, genuine, and looking for real connections. I enjoy good food, great conversations, and spontaneous adventures.",
  location: "Miami, FL",
  age: 32,
  avatar: PHOTOS.f8,
  memberSince: new Date(Date.now() - 86400000 * 60).toISOString(),
  isOnline: true,
  isVerified: false,
  averageRating: 4.2,
  reviewCount: 5,
  reviews: [
    {
      id: "r1",
      fromUserId: "u2",
      fromUserName: "Sophia",
      fromUserAvatar: PHOTOS.f1,
      toUserId: "me",
      rating: 5,
      comment: "Genuine, respectful, and great company. Would highly recommend!",
      date: new Date(Date.now() - 86400000 * 5).toISOString(),
    },
    {
      id: "r2",
      fromUserId: "u3",
      fromUserName: "Valentina",
      fromUserAvatar: PHOTOS.f2,
      toUserId: "me",
      rating: 4,
      comment: "Very polite and easy to talk to. Had a great time.",
      date: new Date(Date.now() - 86400000 * 15).toISOString(),
    },
  ],
  favoriteIds: ["l1", "l3"],
  subscriptionPlan: "none",
  subscriptionExpiry: null,
  verificationStatus: "none",
};
