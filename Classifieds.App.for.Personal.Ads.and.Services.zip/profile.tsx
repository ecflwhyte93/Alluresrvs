import { useRouter } from "expo-router";
import {
  Alert,
  FlatList,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { Listing } from "@/lib/data";
import { useAppStore } from "@/lib/store";

function StarDisplay({ rating, size = 14 }: { rating: number; size?: number }) {
  return (
    <View style={{ flexDirection: "row", gap: 2 }}>
      {[1, 2, 3, 4, 5].map((i) => (
        <Text key={i} style={{ fontSize: size, color: i <= Math.round(rating) ? "#D42B2B" : "#3A2A2A" }}>★</Text>
      ))}
    </View>
  );
}

function getExpiryInfo(expiresAt: string): { label: string; urgent: boolean; expired: boolean } {
  const msLeft = new Date(expiresAt).getTime() - Date.now();
  if (msLeft <= 0) return { label: "Expired", urgent: true, expired: true };
  const hoursLeft = Math.floor(msLeft / 3600000);
  const minsLeft = Math.floor((msLeft % 3600000) / 60000);
  if (hoursLeft < 2) return { label: `${hoursLeft}h ${minsLeft}m left`, urgent: true, expired: false };
  if (hoursLeft < 24) return { label: `${hoursLeft}h left`, urgent: false, expired: false };
  const daysLeft = Math.floor(hoursLeft / 24);
  return { label: `${daysLeft}d left`, urgent: false, expired: false };
}

function MyListingCard({
  item, onPress, onDelete, onBoost
}: {
  item: Listing;
  onPress: () => void;
  onDelete: () => void;
  onBoost: () => void;
}) {
  const expiry = getExpiryInfo(item.expiresAt);

  const confirmDelete = () => {
    Alert.alert(
      "Remove Listing",
      "Are you sure you want to remove this listing? This action cannot be undone.",
      [
        { text: "Cancel", style: "cancel" },
        { text: "Remove", style: "destructive", onPress: onDelete },
      ]
    );
  };

  return (
    <View style={[styles.myListingCard, expiry.expired && styles.myListingCardExpired]}>
      <Pressable onPress={expiry.expired ? undefined : onPress} style={({ pressed }) => [{ flex: 1, flexDirection: "row", gap: 12 }, pressed && !expiry.expired && { opacity: 0.85 }]}>
        <View style={{ position: "relative" }}>
          <Image source={{ uri: item.photos[0] }} style={[styles.myListingImg, expiry.expired && { opacity: 0.4 }]} />
          {expiry.expired && (
            <View style={styles.expiredOverlay}>
              <Text style={styles.expiredOverlayText}>EXPIRED</Text>
            </View>
          )}
        </View>
        <View style={{ flex: 1, justifyContent: "space-between" }}>
          <View>
            <Text style={[styles.myListingTitle, expiry.expired && { color: "#5A4F4F" }]} numberOfLines={2}>{item.title}</Text>
            <Text style={styles.myListingCat}>{item.category} · {item.location}</Text>
          </View>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
            <View style={[styles.expiryPill, expiry.urgent && styles.expiryPillUrgent]}>
              <Text style={[styles.expiryPillText, expiry.urgent && { color: expiry.expired ? "#FF4444" : "#FF8080" }]}>
                ⏱ {expiry.label}
              </Text>
            </View>
            {item.isFeatured && !expiry.expired && (
              <View style={styles.featuredPill}>
                <Text style={styles.featuredPillText}>✦ Featured</Text>
              </View>
            )}
          </View>
        </View>
      </Pressable>
      <View style={styles.listingActions}>
        {expiry.expired ? (
          <Pressable
            onPress={onBoost}
            style={({ pressed }) => [styles.boostBtn, pressed && { opacity: 0.85 }]}
          >
            <Text style={styles.boostBtnText}>🔥 Repost</Text>
          </Pressable>
        ) : (
          <Pressable onPress={confirmDelete} style={styles.deleteBtn}>
            <IconSymbol name="trash.fill" size={18} color="#D42B2B" />
          </Pressable>
        )}
        {expiry.expired && (
          <Pressable onPress={confirmDelete} style={styles.deleteBtnSmall}>
            <IconSymbol name="trash.fill" size={15} color="#5A4F4F" />
          </Pressable>
        )}
      </View>
    </View>
  );
}

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { state, dispatch } = useAppStore();
  const { profile, listings } = state;

  const myListings = listings.filter((l) => l.userId === "me" && !l.isDeleted);
  const favListings = listings.filter((l) => profile.favoriteIds.includes(l.id) && !l.isDeleted);

  const memberSince = new Date(profile.memberSince).toLocaleDateString("en-US", {
    month: "long",
    year: "numeric",
  });

  const handleDeleteListing = (id: string) => {
    dispatch({ type: "SOFT_DELETE_LISTING", payload: id });
  };

  const handleBoostListing = (item: Listing) => {
    // Navigate to paywall with the listing data pre-filled for re-posting
    router.push({
      pathname: "/paywall",
      params: {
        listingTitle: item.title,
        listingData: JSON.stringify({ ...item, id: `${item.id}_repost_${Date.now()}`, expiresAt: new Date(Date.now() + 24 * 3600000).toISOString() }),
        isRenew: "true",
      },
    });
  };

  const verificationLabel = () => {
    if (profile.verificationStatus === "verified") return { text: "Verified ✓", color: "#4CAF82" };
    if (profile.verificationStatus === "pending") return { text: "Verification Pending", color: "#F59E0B" };
    return { text: "Not Verified", color: "#7A6F6F" };
  };
  const vLabel = verificationLabel();

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Profile</Text>
          <Pressable onPress={() => router.push("/edit-profile")} style={styles.editBtn}>
            <IconSymbol name="pencil" size={16} color="#F5F0F0" />
            <Text style={styles.editBtnText}>Edit</Text>
          </Pressable>
        </View>

        {/* Profile card */}
        <View style={styles.profileCard}>
          <View style={styles.avatarWrap}>
            <Image source={{ uri: profile.avatar }} style={styles.avatar} />
            {profile.isOnline && <View style={styles.onlineDot} />}
          </View>
          <View style={{ flex: 1 }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
              <Text style={styles.displayName}>{profile.displayName}, {profile.age}</Text>
              {profile.isVerified && (
                <View style={styles.verifiedBadge}>
                  <Text style={styles.verifiedText}>✓</Text>
                </View>
              )}
            </View>
            <Text style={styles.location}>📍 {profile.location}</Text>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: 4 }}>
              <StarDisplay rating={profile.averageRating} />
              <Text style={styles.ratingText}>
                {profile.averageRating.toFixed(1)} ({profile.reviewCount})
              </Text>
            </View>
          </View>
        </View>

        {/* Bio */}
        <View style={styles.bioCard}>
          <Text style={styles.bio}>{profile.bio}</Text>
          <Text style={styles.memberSince}>Member since {memberSince}</Text>
        </View>

        {/* Stats */}
        <View style={styles.statsRow}>
          <View style={styles.statItem}>
            <Text style={styles.statValue}>{myListings.length}</Text>
            <Text style={styles.statLabel}>Active Ads</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statValue}>{profile.reviewCount}</Text>
            <Text style={styles.statLabel}>Reviews</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statValue}>{favListings.length}</Text>
            <Text style={styles.statLabel}>Saved</Text>
          </View>
        </View>

        {/* Verification status */}
        <Pressable
          onPress={() => profile.verificationStatus !== "verified" ? router.push("/verify" as any) : undefined}
          style={({ pressed }) => [styles.verifyRow, pressed && profile.verificationStatus !== "verified" && { opacity: 0.8 }]}
        >
          <IconSymbol name="checkmark.circle.fill" size={20} color={vLabel.color} />
          <View style={{ flex: 1 }}>
            <Text style={[styles.verifyStatus, { color: vLabel.color }]}>{vLabel.text}</Text>
            {profile.verificationStatus !== "verified" && (
              <Text style={styles.verifyHint}>Tap to get verified and boost your listings</Text>
            )}
          </View>
          {profile.verificationStatus !== "verified" && (
            <IconSymbol name="chevron.right" size={16} color="#7A6F6F" />
          )}
        </Pressable>

        {/* Subscription banner */}
        {profile.subscriptionPlan === "none" ? (
          <Pressable
            onPress={() => router.push("/paywall")}
            style={({ pressed }) => [styles.premiumBanner, pressed && { opacity: 0.85 }]}
          >
            <View>
              <Text style={styles.premiumTitle}>✦ Go Premium</Text>
              <Text style={styles.premiumSubtitle}>Post unlimited listings from $10.99/week</Text>
            </View>
            <IconSymbol name="arrow.right" size={18} color="#F5F0F0" />
          </Pressable>
        ) : (
          <View style={styles.activePlanBanner}>
            <View>
              <Text style={styles.activePlanText}>
                ✦ {profile.subscriptionPlan === "weekly" ? "Weekly" : "Monthly"} Pass Active
              </Text>
              <Text style={styles.activePlanExpiry}>
                Expires {profile.subscriptionExpiry ? new Date(profile.subscriptionExpiry).toLocaleDateString() : "—"}
              </Text>
            </View>
            <Pressable onPress={() => router.push("/paywall")} style={styles.renewBtn}>
              <Text style={styles.renewBtnText}>Renew</Text>
            </Pressable>
          </View>
        )}

        {/* My Listings */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>My Ads</Text>
            <Pressable onPress={() => router.push("/(tabs)/post")} style={styles.newAdBtn}>
              <IconSymbol name="plus" size={14} color="#D42B2B" />
              <Text style={styles.newAdBtnText}>New Ad</Text>
            </Pressable>
          </View>
          {myListings.length === 0 ? (
            <View style={styles.emptySection}>
              <Text style={styles.emptySectionText}>You haven't posted any ads yet.</Text>
              <Pressable onPress={() => router.push("/(tabs)/post")} style={styles.postBtn}>
                <Text style={styles.postBtnText}>Post Your First Ad</Text>
              </Pressable>
            </View>
          ) : (
            <View style={{ gap: 10 }}>
              {myListings.map((item) => (
                <MyListingCard
                  key={item.id}
                  item={item}
                  onPress={() => router.push({ pathname: "/listing/[id]", params: { id: item.id } })}
                  onDelete={() => handleDeleteListing(item.id)}
                  onBoost={() => handleBoostListing(item)}
                />
              ))}
            </View>
          )}
        </View>

        {/* Saved Listings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Saved ♥</Text>
          {favListings.length === 0 ? (
            <Text style={styles.emptySectionText}>No saved listings yet.</Text>
          ) : (
            <FlatList
              data={favListings}
              horizontal
              showsHorizontalScrollIndicator={false}
              keyExtractor={(item) => item.id}
              contentContainerStyle={{ gap: 10 }}
              renderItem={({ item }) => (
                <Pressable
                  onPress={() => router.push({ pathname: "/listing/[id]", params: { id: item.id } })}
                  style={styles.miniCard}
                >
                  <Image source={{ uri: item.photos[0] }} style={styles.miniCardImg} />
                  <View style={styles.miniCardInfo}>
                    <Text style={styles.miniCardName} numberOfLines={1}>{item.userName}</Text>
                    <Text style={styles.miniCardCat}>{item.category}</Text>
                  </View>
                </Pressable>
              )}
            />
          )}
        </View>

        {/* Reviews */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Reviews</Text>
          {profile.reviews.length === 0 ? (
            <Text style={styles.emptySectionText}>No reviews yet.</Text>
          ) : (
            profile.reviews.map((review) => (
              <View key={review.id} style={styles.reviewCard}>
                <View style={styles.reviewHeader}>
                  <Image source={{ uri: review.fromUserAvatar }} style={styles.reviewAvatar} />
                  <View style={{ flex: 1 }}>
                    <Text style={styles.reviewerName}>{review.fromUserName}</Text>
                    <Text style={styles.reviewDate}>{new Date(review.date).toLocaleDateString()}</Text>
                  </View>
                  <StarDisplay rating={review.rating} size={13} />
                </View>
                <Text style={styles.reviewComment}>{review.comment}</Text>
              </View>
            ))
          )}
        </View>

        {/* Settings & Legal Links */}
        <View style={styles.settingsGroup}>
          <Pressable onPress={() => router.push("/edit-profile")} style={styles.settingsLink}>
            <IconSymbol name="gear" size={18} color="#7A6F6F" />
            <Text style={styles.settingsLinkText}>Settings & Preferences</Text>
            <IconSymbol name="chevron.right" size={16} color="#5A4F4F" />
          </Pressable>
          <View style={styles.settingsDivider} />
          <Pressable onPress={() => router.push("/notifications" as any)} style={styles.settingsLink}>
            <IconSymbol name="bell.fill" size={18} color="#7A6F6F" />
            <Text style={styles.settingsLinkText}>Notifications</Text>
            <IconSymbol name="chevron.right" size={16} color="#5A4F4F" />
          </Pressable>
          <View style={styles.settingsDivider} />
          <Pressable onPress={() => router.push("/verify")} style={styles.settingsLink}>
            <IconSymbol name="checkmark.seal.fill" size={18} color="#7A6F6F" />
            <Text style={styles.settingsLinkText}>Photo Verification</Text>
            <IconSymbol name="chevron.right" size={16} color="#5A4F4F" />
          </Pressable>
          <View style={styles.settingsDivider} />
          <Pressable onPress={() => router.push("/terms" as any)} style={styles.settingsLink}>
            <IconSymbol name="doc.text.fill" size={18} color="#7A6F6F" />
            <Text style={styles.settingsLinkText}>Terms of Service</Text>
            <IconSymbol name="chevron.right" size={16} color="#5A4F4F" />
          </Pressable>
          <View style={styles.settingsDivider} />
          <Pressable onPress={() => router.push("/privacy" as any)} style={styles.settingsLink}>
            <IconSymbol name="lock.fill" size={18} color="#7A6F6F" />
            <Text style={styles.settingsLinkText}>Privacy Policy</Text>
            <IconSymbol name="chevron.right" size={16} color="#5A4F4F" />
          </Pressable>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0A0A0A" },
  scrollContent: { paddingBottom: 100 },
  header: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 20, paddingBottom: 16, paddingTop: 8,
  },
  headerTitle: { color: "#F5F0F0", fontSize: 26, fontWeight: "800" },
  editBtn: {
    flexDirection: "row", alignItems: "center", gap: 6,
    backgroundColor: "#161618", borderRadius: 10,
    paddingHorizontal: 14, paddingVertical: 8,
    borderWidth: 1, borderColor: "#2A1F1F",
  },
  editBtnText: { color: "#F5F0F0", fontSize: 13, fontWeight: "600" },
  profileCard: {
    flexDirection: "row", alignItems: "center", gap: 16,
    paddingHorizontal: 20, marginBottom: 12,
  },
  avatarWrap: { position: "relative" },
  avatar: { width: 72, height: 72, borderRadius: 36, borderWidth: 3, borderColor: "#D42B2B" },
  onlineDot: {
    position: "absolute", bottom: 2, right: 2,
    width: 14, height: 14, borderRadius: 7,
    backgroundColor: "#4CAF82", borderWidth: 2, borderColor: "#0A0A0A",
  },
  displayName: { color: "#F5F0F0", fontSize: 20, fontWeight: "800" },
  location: { color: "#7A6F6F", fontSize: 13, marginTop: 2 },
  ratingText: { color: "#7A6F6F", fontSize: 12 },
  verifiedBadge: {
    backgroundColor: "#D42B2B", borderRadius: 10,
    width: 18, height: 18, alignItems: "center", justifyContent: "center",
  },
  verifiedText: { color: "#F5F0F0", fontSize: 10, fontWeight: "900" },
  bioCard: {
    marginHorizontal: 20, marginBottom: 16,
    backgroundColor: "#161618", borderRadius: 14,
    padding: 14, borderWidth: 1, borderColor: "#2A1F1F",
  },
  bio: { color: "#C5B8B8", fontSize: 13, lineHeight: 20 },
  memberSince: { color: "#7A6F6F", fontSize: 11, marginTop: 8 },
  statsRow: {
    flexDirection: "row", marginHorizontal: 20, marginBottom: 16,
    backgroundColor: "#161618", borderRadius: 14,
    padding: 16, borderWidth: 1, borderColor: "#2A1F1F",
  },
  statItem: { flex: 1, alignItems: "center" },
  statValue: { color: "#D42B2B", fontSize: 22, fontWeight: "800" },
  statLabel: { color: "#7A6F6F", fontSize: 11, marginTop: 2 },
  statDivider: { width: 1, backgroundColor: "#2A1F1F" },
  verifyRow: {
    flexDirection: "row", alignItems: "center", gap: 12,
    marginHorizontal: 20, marginBottom: 16,
    backgroundColor: "#161618", borderRadius: 14,
    padding: 14, borderWidth: 1, borderColor: "#2A1F1F",
  },
  verifyStatus: { fontSize: 14, fontWeight: "700" },
  verifyHint: { fontSize: 11, color: "#7A6F6F", marginTop: 2 },
  premiumBanner: {
    marginHorizontal: 20, marginBottom: 20,
    backgroundColor: "#D42B2B", borderRadius: 14,
    padding: 16, flexDirection: "row", alignItems: "center", justifyContent: "space-between",
  },
  premiumTitle: { color: "#F5F0F0", fontSize: 16, fontWeight: "800" },
  premiumSubtitle: { color: "rgba(245,240,240,0.8)", fontSize: 12, marginTop: 2 },
  activePlanBanner: {
    marginHorizontal: 20, marginBottom: 20,
    backgroundColor: "#1A1010", borderRadius: 14,
    padding: 14, borderWidth: 1, borderColor: "#D42B2B",
    flexDirection: "row", justifyContent: "space-between", alignItems: "center",
  },
  activePlanText: { color: "#D42B2B", fontSize: 14, fontWeight: "700" },
  activePlanExpiry: { color: "#7A6F6F", fontSize: 12, marginTop: 2 },
  renewBtn: {
    paddingHorizontal: 14, paddingVertical: 7,
    borderRadius: 10, borderWidth: 1, borderColor: "#D42B2B",
  },
  renewBtnText: { color: "#D42B2B", fontSize: 13, fontWeight: "700" },
  section: { paddingHorizontal: 20, marginBottom: 24 },
  sectionHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 },
  sectionTitle: { color: "#F5F0F0", fontSize: 17, fontWeight: "700" },
  newAdBtn: {
    flexDirection: "row", alignItems: "center", gap: 4,
    paddingHorizontal: 12, paddingVertical: 6,
    borderRadius: 10, borderWidth: 1, borderColor: "#D42B2B",
  },
  newAdBtnText: { color: "#D42B2B", fontSize: 12, fontWeight: "700" },
  emptySection: { gap: 10 },
  emptySectionText: { color: "#7A6F6F", fontSize: 13 },
  postBtn: {
    backgroundColor: "#D42B2B", borderRadius: 12,
    paddingHorizontal: 20, paddingVertical: 12, alignSelf: "flex-start",
  },
  postBtnText: { color: "#F5F0F0", fontSize: 14, fontWeight: "700" },
  myListingCard: {
    flexDirection: "row", alignItems: "center", gap: 0,
    backgroundColor: "#161618", borderRadius: 14,
    borderWidth: 1, borderColor: "#2A1F1F", overflow: "hidden",
  },
  myListingCardExpired: { borderColor: "#3A2A2A" },
  expiredOverlay: {
    position: "absolute", top: 0, left: 0, right: 0, bottom: 0,
    backgroundColor: "rgba(10,10,10,0.6)", alignItems: "center", justifyContent: "center",
  },
  expiredOverlayText: { color: "#FF4444", fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  myListingImg: { width: 80, height: 90 },
  myListingTitle: { color: "#F5F0F0", fontSize: 13, fontWeight: "700", lineHeight: 18, paddingTop: 10, paddingRight: 8 },
  myListingCat: { color: "#7A6F6F", fontSize: 11, marginTop: 4 },
  expiryPill: {
    paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10,
    backgroundColor: "#1A1010", borderWidth: 1, borderColor: "#3A2A2A",
  },
  expiryPillUrgent: { borderColor: "#D42B2B" },
  expiryPillText: { color: "#9A8F8F", fontSize: 10, fontWeight: "700" },
  featuredPill: {
    paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10,
    backgroundColor: "#2A1010",
  },
  featuredPillText: { color: "#D42B2B", fontSize: 10, fontWeight: "700" },
  listingActions: {
    flexDirection: "column", alignItems: "center", justifyContent: "center",
    borderLeftWidth: 1, borderLeftColor: "#2A1F1F", gap: 4, paddingHorizontal: 4,
  },
  deleteBtn: {
    paddingHorizontal: 14, paddingVertical: 10, alignSelf: "stretch",
    alignItems: "center", justifyContent: "center",
  },
  deleteBtnSmall: {
    paddingHorizontal: 10, paddingVertical: 6,
    alignItems: "center", justifyContent: "center",
  },
  boostBtn: {
    backgroundColor: "#D42B2B", borderRadius: 10,
    paddingHorizontal: 10, paddingVertical: 8, margin: 6,
    alignItems: "center",
  },
  boostBtnText: { color: "#F5F0F0", fontSize: 11, fontWeight: "800" },
  miniCard: {
    width: 130, backgroundColor: "#161618",
    borderRadius: 12, overflow: "hidden",
    borderWidth: 1, borderColor: "#2A1F1F",
  },
  miniCardImg: { width: "100%", height: 90 },
  miniCardInfo: { padding: 8 },
  miniCardName: { color: "#F5F0F0", fontSize: 12, fontWeight: "600" },
  miniCardCat: { color: "#D42B2B", fontSize: 10, marginTop: 2 },
  reviewCard: {
    backgroundColor: "#161618", borderRadius: 12,
    padding: 14, marginBottom: 10,
    borderWidth: 1, borderColor: "#2A1F1F",
  },
  reviewHeader: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 8 },
  reviewAvatar: { width: 36, height: 36, borderRadius: 18 },
  reviewerName: { color: "#F5F0F0", fontSize: 13, fontWeight: "700" },
  reviewDate: { color: "#7A6F6F", fontSize: 11, marginTop: 1 },
  reviewComment: { color: "#C5B8B8", fontSize: 13, lineHeight: 19 },
  settingsGroup: {
    marginHorizontal: 20, marginBottom: 30,
    backgroundColor: "#161618", borderRadius: 14,
    borderWidth: 1, borderColor: "#2A1F1F", overflow: "hidden",
  },
  settingsLink: {
    flexDirection: "row", alignItems: "center", gap: 12,
    padding: 16,
  },
  settingsDivider: { height: 1, backgroundColor: "#2A1F1F", marginHorizontal: 16 },
  settingsLinkText: { flex: 1, color: "#7A6F6F", fontSize: 14 },
});
