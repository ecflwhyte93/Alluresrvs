/** @type {const} */
const themeColors = {
  primary:    { light: '#D42B2B', dark: '#D42B2B' },
  background: { light: '#0A0A0A', dark: '#0A0A0A' },
  surface:    { light: '#161618', dark: '#161618' },
  foreground: { light: '#F5F0F0', dark: '#F5F0F0' },
  muted:      { light: '#7A6F6F', dark: '#7A6F6F' },
  border:     { light: '#2A1F1F', dark: '#2A1F1F' },
  success:    { light: '#4CAF82', dark: '#4CAF82' },
  warning:    { light: '#F59E0B', dark: '#FBBF24' },
  error:      { light: '#FF4444', dark: '#FF4444' },
  tint:       { light: '#D42B2B', dark: '#D42B2B' },
};

module.exports = { themeColors };
