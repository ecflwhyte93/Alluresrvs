# Allure — Project TODO

## Theme & Navigation
- [x] Update theme.config.js with black and red palette
- [x] Update tailwind.config.js with custom colors
- [x] Set up bottom tab navigation (Explore, Post, Messages, Profile)
- [x] Add all required icon mappings to icon-symbol.tsx
- [x] Update app.config.ts with app name "Allure"

## Data & State
- [x] Define listing data types and mock data
- [x] Define message/conversation data types
- [x] Set up AsyncStorage persistence for listings, messages, profile, favorites

## Explore Screen
- [x] Search bar at top
- [x] Category filter pills (All, Dating, Hookups, Companionship, Events)
- [x] FlatList of listing cards (photo, name, age, city, online badge, category)
- [x] Featured/premium listing highlight with red glow

## Listing Detail Screen
- [x] Hero image carousel (swipeable)
- [x] Name, age, location, online status badge
- [x] Category badge
- [x] Description and tags/interests
- [x] Message CTA button
- [x] Save/Favorite toggle button
- [x] Report listing option

## Post Listing Screen (Multi-step)
- [x] Step 1: Category selection
- [x] Step 2: Photo upload (up to 6 images)
- [x] Step 3: Title, description, tags, contact preferences
- [x] Step 4: Preview listing
- [x] Trigger paywall before publishing

## Monetization / Paywall Screen
- [x] Single Post plan ($5.99)
- [x] Weekly Pass plan ($10.99/week)
- [x] Monthly Pass plan ($29.99/month)
- [x] Plan selection UI with highlighted recommended plan
- [x] Mock payment confirmation flow

## Messages Screen
- [x] Conversation list (avatar, name, last message, timestamp, unread badge)
- [x] Empty state UI

## Chat Screen
- [x] Bubble-style message thread
- [x] Text input with send button
- [x] Timestamp display
- [x] Mark conversation as complete

## Profile Screen
- [x] Avatar, display name, bio, location
- [x] Member since, listing count stats
- [x] Grid of own listings
- [x] Edit profile button
- [x] "Go Premium" subscription CTA
- [x] Saved/Favorites section
- [x] Reviews list

## Settings Screen
- [x] Edit display name, bio, location, age
- [x] Clear data option

## Favorites
- [x] Save/unsave listings from detail screen
- [x] Favorites section in Profile

## Branding
- [x] Generate app logo (black/red, luxury)
- [x] Update app icon, splash screen, favicon
- [x] Update app.config.ts with logo URL and app name "Allure"

## Ratings & Safety System
- [x] Mutual rating model: both client and poster can rate each other after interaction
- [x] 1–5 star rating with optional short text review
- [x] Rating prompt appears after a conversation is marked complete
- [x] Display average star rating + review count on profile and listing cards
- [x] Verified badge for users with 4.5+ average rating
- [x] Reviews list on profile screen (who rated, stars, comment, date)
- [x] Safety tip banner on listing detail screen

## Phase 2 — New Features
- [x] Real photo upload in Post screen (expo-image-picker)
- [x] Push notifications for new messages (expo-notifications)
- [x] Location-based filtering on Explore screen
- [x] Advertiser photo verification flow (selfie + ID upload)
- [x] Verified badge awarded after photo verification
- [x] 24-hour post expiry for single post plan
- [x] Expiry countdown timer visible on listing cards and detail screen
- [x] Auto-removal of expired listings
- [x] Delete/remove post button for poster (own listings)
- [x] Confirmation dialog before deleting a post
- [x] Expired/deleted listings shown as inactive in My Listings

## Phase 3 — Next Steps
- [x] Stripe payment integration for $5.99 single post
- [x] Stripe payment integration for $10.99/week subscription
- [x] Stripe payment integration for $29.99/month subscription
- [x] Payment confirmation screen with receipt
- [x] Real-time messaging via backend (tRPC polling, 3-second intervals)
- [x] Messages update live without manual refresh (optimistic updates)
- [x] Unread badge updates in real-time
- [x] Boost/re-post expired ads button in My Ads (🔥 Repost)
- [x] One-tap renew flow for expired listings
- [x] Renew triggers paywall with pre-selected plan and listing data

## Phase 4 — Release Readiness
- [x] Stripe Secret Key wired via environment secret
- [x] Onboarding / welcome screen (first launch)
- [x] Age verification gate (18+ confirmation)
- [x] Advanced search filters modal (age range, distance, category, verified-only, online-only, featured-first)
- [x] In-app notification center (bell icon, notification history, animated bell)
- [x] Push notification trigger on new message send
- [x] Photo lightbox / full-screen gallery (tap to expand, swipeable)
- [x] Report listing flow (reason selection + confirmation modal)
- [x] Block user from listing detail screen
- [x] Privacy Policy screen (full legal content)
- [x] Terms of Service screen (full legal content)
- [x] Settings group in Profile (Settings, Notifications, Verify, Terms, Privacy)
- [x] App store polish (custom icon, splash, branding)
