import { useLocalSearchParams, useRouter } from "expo-router";
import { ActivityIndicator, Alert, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRef, useState } from "react";

import { IconSymbol } from "@/components/ui/icon-symbol";
import { useAppStore } from "@/lib/store";
import { trpc } from "@/lib/trpc";

const PLANS = [
  {
    id: "single",
    label: "Single Post",
    price: "$5.99",
    period: "one-time",
    description: "Post one listing, active for 30 days",
    features: ["1 listing", "30-day visibility", "Basic support"],
    recommended: false,
  },
  {
    id: "weekly",
    label: "Weekly Pass",
    price: "$10.99",
    period: "per week",
    description: "Unlimited posts for 7 days",
    features: ["Unlimited listings", "7-day access", "Priority placement", "Featured badge"],
    recommended: false,
  },
  {
    id: "monthly",
    label: "Monthly Pass",
    price: "$29.99",
    period: "per month",
    description: "Best value — unlimited posts for 30 days",
    features: ["Unlimited listings", "30-day access", "Priority placement", "Featured badge", "Profile verification"],
    recommended: true,
  },
];

export default function PaywallScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const params = useLocalSearchParams<{ plan?: string; listingTitle?: string; listingData?: string; isRenew?: string }>();
  const { dispatch } = useAppStore();
  const [selected, setSelected] = useState(params.plan ?? "monthly");
  const [loading, setLoading] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  const selectedPlan = PLANS.find((p) => p.id === selected)!;
  const deviceId = useRef(`device_${Date.now()}_${Math.random().toString(36).slice(2)}`).current;

  const createIntentMutation = trpc.payments.createIntent.useMutation();
  const confirmMutation = trpc.payments.confirmPayment.useMutation();

  const applyPlanLocally = (planId: string, expiry: string) => {
    const plan: "weekly" | "monthly" | "none" =
      planId === "weekly" ? "weekly" : planId === "monthly" ? "monthly" : "none";
    dispatch({ type: "SET_SUBSCRIPTION", payload: { plan, expiry } });
    if (params.listingData) {
      try {
        const listing = JSON.parse(params.listingData);
        listing.expiresAt = expiry;
        dispatch({ type: "ADD_LISTING", payload: listing });
      } catch { /* ignore */ }
    }
  };

  const handlePurchase = async () => {
    setLoading(true);
    try {
      const result = await createIntentMutation.mutateAsync({
        plan: selected as "single" | "weekly" | "monthly",
        userId: deviceId,
        listingTitle: params.listingTitle,
      });

      const now = new Date();
      const expiry = selected === "single"
        ? new Date(now.getTime() + 24 * 3600000).toISOString()
        : selected === "weekly"
        ? new Date(now.getTime() + 7 * 86400000).toISOString()
        : new Date(now.getTime() + 30 * 86400000).toISOString();

      if (result.isDev || !result.clientSecret) {
        // Dev mode — no Stripe key, instant success
        await confirmMutation.mutateAsync({ paymentId: result.paymentId }).catch(() => {});
        applyPlanLocally(selected, expiry);
        setPaymentSuccess(true);
        return;
      }

      // Real Stripe — show confirmation then process
      Alert.alert(
        "Complete Payment",
        `Confirm ${selectedPlan.price} payment for ${selectedPlan.label}?`,
        [
          { text: "Cancel", style: "cancel" },
          {
            text: "Confirm Payment",
            onPress: async () => {
              try {
                await confirmMutation.mutateAsync({ paymentId: result.paymentId });
                applyPlanLocally(selected, expiry);
                setPaymentSuccess(true);
              } catch (err: any) {
                Alert.alert("Error", err?.message ?? "Payment confirmation failed.");
              }
            },
          },
        ]
      );
    } catch (err: any) {
      Alert.alert("Payment Error", err?.message ?? "Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  if (paymentSuccess) {
    return (
      <View style={[styles.container, { paddingTop: insets.top, paddingBottom: insets.bottom + 20 }]}>
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", padding: 32 }}>
          <View style={{ width: 90, height: 90, borderRadius: 45, backgroundColor: "#1A1010", borderWidth: 2, borderColor: "#D42B2B", alignItems: "center", justifyContent: "center", marginBottom: 24 }}>
            <Text style={{ fontSize: 40 }}>✦</Text>
          </View>
          <Text style={{ color: "#F5F0F0", fontSize: 26, fontWeight: "900", marginBottom: 8 }}>Payment Successful!</Text>
          <Text style={{ color: "#9A8F8F", fontSize: 14, textAlign: "center", lineHeight: 21, marginBottom: 28 }}>
            Your {selectedPlan.label} is now active.
          </Text>
          <View style={{ backgroundColor: "#161618", borderRadius: 16, padding: 20, width: "100%", alignItems: "center", borderWidth: 1, borderColor: "#D42B2B", marginBottom: 32 }}>
            <Text style={{ color: "#D42B2B", fontSize: 16, fontWeight: "800", marginBottom: 4 }}>{selectedPlan.label}</Text>
            <Text style={{ color: "#F5F0F0", fontSize: 32, fontWeight: "900", marginBottom: 4 }}>{selectedPlan.price}</Text>
            <Text style={{ color: "#9A8F8F", fontSize: 13 }}>{selectedPlan.period}</Text>
          </View>
          <Pressable
            onPress={() => params.isRenew === "true" ? router.back() : router.replace("/(tabs)")}
            style={({ pressed }) => [styles.purchaseBtn, { paddingHorizontal: 48 }, pressed && { opacity: 0.85 }]}
          >
            <Text style={styles.purchaseBtnText}>{params.isRenew === "true" ? "Back to My Ads" : "Start Browsing"}</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.closeBtn}>
          <IconSymbol name="xmark" size={18} color="#F5F0F0" />
        </Pressable>
        <View style={styles.headerCenter}>
          <Text style={styles.headerTitle}>✦ Choose Your Plan</Text>
          <Text style={styles.headerSubtitle}>Unlock the full Allure experience</Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {PLANS.map((plan) => (
          <Pressable
            key={plan.id}
            onPress={() => setSelected(plan.id)}
            style={[
              styles.planCard,
              selected === plan.id && styles.planCardSelected,
              plan.recommended && styles.planCardRecommended,
            ]}
          >
            {plan.recommended && (
              <View style={styles.recommendedBadge}>
                <Text style={styles.recommendedText}>BEST VALUE</Text>
              </View>
            )}
            <View style={styles.planTop}>
              <View style={{ flex: 1 }}>
                <Text style={styles.planLabel}>{plan.label}</Text>
                <Text style={styles.planDescription}>{plan.description}</Text>
              </View>
              <View style={styles.planPriceWrap}>
                <Text style={styles.planPrice}>{plan.price}</Text>
                <Text style={styles.planPeriod}>{plan.period}</Text>
              </View>
            </View>
            <View style={styles.planFeatures}>
              {plan.features.map((f) => (
                <View key={f} style={styles.featureRow}>
                  <Text style={styles.featureCheck}>✓</Text>
                  <Text style={styles.featureText}>{f}</Text>
                </View>
              ))}
            </View>
            <View style={[styles.radioOuter, selected === plan.id && styles.radioOuterSelected]}>
              {selected === plan.id && <View style={styles.radioInner} />}
            </View>
          </Pressable>
        ))}

        <View style={styles.trustRow}>
          <View style={styles.trustItem}>
            <Text style={styles.trustIcon}>🔒</Text>
            <Text style={styles.trustText}>Secure Payment</Text>
          </View>
          <View style={styles.trustItem}>
            <Text style={styles.trustIcon}>🛡️</Text>
            <Text style={styles.trustText}>Cancel Anytime</Text>
          </View>
          <View style={styles.trustItem}>
            <Text style={styles.trustIcon}>⚡</Text>
            <Text style={styles.trustText}>Instant Access</Text>
          </View>
        </View>

        <Text style={styles.disclaimer}>
          By purchasing, you agree to our Terms of Service. Subscriptions auto-renew unless cancelled 24 hours before the renewal date.
        </Text>
      </ScrollView>

      <View style={[styles.ctaBar, { paddingBottom: insets.bottom + 12 }]}>
        <Pressable
          onPress={handlePurchase}
          disabled={loading}
          style={[styles.purchaseBtn, loading && { opacity: 0.7 }]}
        >
          <Text style={styles.purchaseBtnText}>
            {loading ? "Processing..." : `Get ${selectedPlan.label} — ${selectedPlan.price}`}
          </Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0A0A0A" },
  header: {
    flexDirection: "row", alignItems: "center",
    paddingHorizontal: 20, paddingBottom: 16, paddingTop: 8, gap: 12,
  },
  closeBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: "#161618", alignItems: "center", justifyContent: "center",
    borderWidth: 1, borderColor: "#2A1F1F",
  },
  headerCenter: { flex: 1 },
  headerTitle: { color: "#F5F0F0", fontSize: 20, fontWeight: "800" },
  headerSubtitle: { color: "#7A6F6F", fontSize: 12, marginTop: 2 },
  scrollContent: { paddingHorizontal: 20, paddingBottom: 20, gap: 14 },
  planCard: {
    backgroundColor: "#161618", borderRadius: 16,
    padding: 18, borderWidth: 1.5, borderColor: "#2A1F1F",
    position: "relative",
  },
  planCardSelected: { borderColor: "#D42B2B", backgroundColor: "#1A1010" },
  planCardRecommended: { borderColor: "#D42B2B" },
  recommendedBadge: {
    position: "absolute", top: -10, left: 18,
    backgroundColor: "#D42B2B", borderRadius: 8,
    paddingHorizontal: 10, paddingVertical: 4,
  },
  recommendedText: { color: "#F5F0F0", fontSize: 10, fontWeight: "800", letterSpacing: 1 },
  planTop: { flexDirection: "row", alignItems: "flex-start", marginBottom: 12 },
  planLabel: { color: "#F5F0F0", fontSize: 17, fontWeight: "700" },
  planDescription: { color: "#7A6F6F", fontSize: 12, marginTop: 3 },
  planPriceWrap: { alignItems: "flex-end" },
  planPrice: { color: "#D42B2B", fontSize: 24, fontWeight: "900" },
  planPeriod: { color: "#7A6F6F", fontSize: 11, marginTop: 1 },
  planFeatures: { gap: 6, marginBottom: 12 },
  featureRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  featureCheck: { color: "#D42B2B", fontSize: 13, fontWeight: "700" },
  featureText: { color: "#C5B8B8", fontSize: 13 },
  radioOuter: {
    position: "absolute", top: 18, right: 18,
    width: 22, height: 22, borderRadius: 11,
    borderWidth: 2, borderColor: "#2A1F1F",
    alignItems: "center", justifyContent: "center",
  },
  radioOuterSelected: { borderColor: "#D42B2B" },
  radioInner: { width: 12, height: 12, borderRadius: 6, backgroundColor: "#D42B2B" },
  trustRow: {
    flexDirection: "row", justifyContent: "space-around",
    backgroundColor: "#161618", borderRadius: 14,
    padding: 14, borderWidth: 1, borderColor: "#2A1F1F",
  },
  trustItem: { alignItems: "center", gap: 4 },
  trustIcon: { fontSize: 20 },
  trustText: { color: "#7A6F6F", fontSize: 10, textAlign: "center" },
  disclaimer: { color: "#7A6F6F", fontSize: 11, textAlign: "center", lineHeight: 16 },
  ctaBar: {
    paddingHorizontal: 20, paddingTop: 12,
    backgroundColor: "#0F0F0F", borderTopWidth: 1, borderTopColor: "#2A1F1F",
  },
  purchaseBtn: {
    backgroundColor: "#D42B2B", borderRadius: 14,
    paddingVertical: 18, alignItems: "center",
  },
  purchaseBtnText: { color: "#F5F0F0", fontSize: 16, fontWeight: "800" },
});
