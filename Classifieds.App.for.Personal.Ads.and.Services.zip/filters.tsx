import AsyncStorage from "@react-native-async-storage/async-storage";
import { useRouter } from "expo-router";
import { useEffect, useState } from "react";
import {
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { Category } from "@/lib/data";

const CATEGORIES: Category[] = ["All", "Dating", "Hookups", "Companionship", "Events", "Other"];
const STORAGE_KEY = "allure_filters";

export type FilterState = {
  category: Category;
  minAge: string;
  maxAge: string;
  verifiedOnly: boolean;
  onlineOnly: boolean;
  featuredFirst: boolean;
  location: string;
};

const DEFAULT_FILTERS: FilterState = {
  category: "All",
  minAge: "18",
  maxAge: "60",
  verifiedOnly: false,
  onlineOnly: false,
  featuredFirst: true,
  location: "",
};

export default function FiltersScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [filters, setFilters] = useState<FilterState>(DEFAULT_FILTERS);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((val) => {
      if (val) setFilters(JSON.parse(val));
    });
  }, []);

  const update = (key: keyof FilterState, value: any) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  const handleApply = async () => {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(filters));
    router.back();
  };

  const handleReset = async () => {
    setFilters(DEFAULT_FILTERS);
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_FILTERS));
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.closeBtn}>
          <IconSymbol name="xmark" size={18} color="#F5F0F0" />
        </Pressable>
        <Text style={styles.title}>Filters</Text>
        <Pressable onPress={handleReset}>
          <Text style={styles.resetText}>Reset</Text>
        </Pressable>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        {/* Category */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Category</Text>
          <View style={styles.chipRow}>
            {CATEGORIES.map((cat) => (
              <Pressable
                key={cat}
                onPress={() => update("category", cat)}
                style={[styles.chip, filters.category === cat && styles.chipActive]}
              >
                <Text style={[styles.chipText, filters.category === cat && styles.chipTextActive]}>
                  {cat}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Age Range */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Age Range</Text>
          <View style={styles.ageRow}>
            <View style={styles.ageInput}>
              <Text style={styles.ageLabel}>Min</Text>
              <TextInput
                value={filters.minAge}
                onChangeText={(v) => update("minAge", v.replace(/[^0-9]/g, ""))}
                keyboardType="numeric"
                style={styles.ageField}
                maxLength={2}
                returnKeyType="done"
                placeholderTextColor="#5A4F4F"
              />
            </View>
            <Text style={styles.ageDash}>—</Text>
            <View style={styles.ageInput}>
              <Text style={styles.ageLabel}>Max</Text>
              <TextInput
                value={filters.maxAge}
                onChangeText={(v) => update("maxAge", v.replace(/[^0-9]/g, ""))}
                keyboardType="numeric"
                style={styles.ageField}
                maxLength={2}
                returnKeyType="done"
                placeholderTextColor="#5A4F4F"
              />
            </View>
          </View>
        </View>

        {/* Location */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Location</Text>
          <View style={styles.inputRow}>
            <IconSymbol name="location.fill" size={16} color="#D42B2B" />
            <TextInput
              value={filters.location}
              onChangeText={(v) => update("location", v)}
              placeholder="City, state or zip..."
              placeholderTextColor="#5A4F4F"
              style={styles.textField}
              returnKeyType="done"
            />
            {filters.location.length > 0 && (
              <Pressable onPress={() => update("location", "")}>
                <IconSymbol name="xmark.circle.fill" size={16} color="#7A6F6F" />
              </Pressable>
            )}
          </View>
        </View>

        {/* Toggle Filters */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Show Only</Text>

          <View style={styles.toggleRow}>
            <View style={styles.toggleInfo}>
              <Text style={styles.toggleLabel}>Verified Profiles</Text>
              <Text style={styles.toggleSub}>Only show photo-verified users</Text>
            </View>
            <Switch
              value={filters.verifiedOnly}
              onValueChange={(v) => update("verifiedOnly", v)}
              trackColor={{ false: "#2A1F1F", true: "#D42B2B" }}
              thumbColor={filters.verifiedOnly ? "#F5F0F0" : "#7A6F6F"}
            />
          </View>

          <View style={[styles.toggleRow, { marginTop: 12 }]}>
            <View style={styles.toggleInfo}>
              <Text style={styles.toggleLabel}>Online Now</Text>
              <Text style={styles.toggleSub}>Only show currently active users</Text>
            </View>
            <Switch
              value={filters.onlineOnly}
              onValueChange={(v) => update("onlineOnly", v)}
              trackColor={{ false: "#2A1F1F", true: "#D42B2B" }}
              thumbColor={filters.onlineOnly ? "#F5F0F0" : "#7A6F6F"}
            />
          </View>

          <View style={[styles.toggleRow, { marginTop: 12 }]}>
            <View style={styles.toggleInfo}>
              <Text style={styles.toggleLabel}>Featured First</Text>
              <Text style={styles.toggleSub}>Show premium listings at the top</Text>
            </View>
            <Switch
              value={filters.featuredFirst}
              onValueChange={(v) => update("featuredFirst", v)}
              trackColor={{ false: "#2A1F1F", true: "#D42B2B" }}
              thumbColor={filters.featuredFirst ? "#F5F0F0" : "#7A6F6F"}
            />
          </View>
        </View>
      </ScrollView>

      {/* Apply Button */}
      <View style={[styles.footer, { paddingBottom: insets.bottom + 16 }]}>
        <Pressable
          onPress={handleApply}
          style={({ pressed }) => [styles.applyBtn, pressed && { opacity: 0.85 }]}
        >
          <Text style={styles.applyBtnText}>Apply Filters</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0A0A0A" },
  header: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 20, paddingVertical: 16,
    borderBottomWidth: 1, borderBottomColor: "#1A1A1A",
  },
  closeBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: "#161618", alignItems: "center", justifyContent: "center",
  },
  title: { color: "#F5F0F0", fontSize: 18, fontWeight: "800" },
  resetText: { color: "#D42B2B", fontSize: 14, fontWeight: "700" },
  content: { padding: 20, gap: 24, paddingBottom: 100 },
  section: {},
  sectionTitle: { color: "#F5F0F0", fontSize: 15, fontWeight: "700", marginBottom: 12 },
  chipRow: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  chip: {
    paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20,
    backgroundColor: "#161618", borderWidth: 1, borderColor: "#2A1F1F",
  },
  chipActive: { backgroundColor: "#D42B2B", borderColor: "#D42B2B" },
  chipText: { color: "#7A6F6F", fontSize: 13, fontWeight: "600" },
  chipTextActive: { color: "#F5F0F0" },
  ageRow: { flexDirection: "row", alignItems: "center", gap: 16 },
  ageInput: {
    flex: 1, backgroundColor: "#161618", borderRadius: 12,
    borderWidth: 1, borderColor: "#2A1F1F", padding: 12,
  },
  ageLabel: { color: "#7A6F6F", fontSize: 11, marginBottom: 4 },
  ageField: { color: "#F5F0F0", fontSize: 22, fontWeight: "700" },
  ageDash: { color: "#5A4F4F", fontSize: 20 },
  inputRow: {
    flexDirection: "row", alignItems: "center", gap: 10,
    backgroundColor: "#161618", borderRadius: 12,
    borderWidth: 1, borderColor: "#2A1F1F", paddingHorizontal: 14, paddingVertical: 12,
  },
  textField: { flex: 1, color: "#F5F0F0", fontSize: 14 },
  toggleRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  toggleInfo: { flex: 1, marginRight: 16 },
  toggleLabel: { color: "#F5F0F0", fontSize: 14, fontWeight: "600" },
  toggleSub: { color: "#7A6F6F", fontSize: 12, marginTop: 2 },
  footer: { paddingHorizontal: 20, paddingTop: 12, borderTopWidth: 1, borderTopColor: "#1A1A1A" },
  applyBtn: {
    backgroundColor: "#D42B2B", borderRadius: 16,
    paddingVertical: 16, alignItems: "center",
  },
  applyBtnText: { color: "#F5F0F0", fontSize: 17, fontWeight: "800" },
});
