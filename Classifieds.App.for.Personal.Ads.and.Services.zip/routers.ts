import { z } from "zod";
import Stripe from "stripe";
import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import * as db from "./db";

function getStripe(): Stripe | null {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) return null;
  return new Stripe(key, { apiVersion: "2025-03-31.basil" });
}

const PLAN_PRICES: Record<string, number> = {
  single: 599,
  weekly: 1099,
  monthly: 2999,
};

const PLAN_LABELS: Record<string, string> = {
  single: "Single Post — 24 hours",
  weekly: "Weekly Pass — 7 days",
  monthly: "Monthly Pass — 30 days",
};

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  payments: router({
    createIntent: publicProcedure
      .input(z.object({
        plan: z.enum(["single", "weekly", "monthly"]),
        userId: z.string().min(1),
        listingTitle: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const stripe = getStripe();
        const amount = PLAN_PRICES[input.plan];
        if (!stripe) {
          const paymentId = await db.createPayment({
            userId: input.userId,
            plan: input.plan,
            amount,
            currency: "usd",
            status: "succeeded",
            listingTitle: input.listingTitle,
          });
          return { paymentId, clientSecret: null, isDev: true, plan: input.plan, amount };
        }
        const intent = await stripe.paymentIntents.create({
          amount,
          currency: "usd",
          description: PLAN_LABELS[input.plan],
          metadata: { userId: input.userId, plan: input.plan, listingTitle: input.listingTitle ?? "" },
          automatic_payment_methods: { enabled: true },
        });
        const paymentId = await db.createPayment({
          userId: input.userId,
          plan: input.plan,
          amount,
          currency: "usd",
          status: "pending",
          stripePaymentIntentId: intent.id,
          stripeClientSecret: intent.client_secret,
          listingTitle: input.listingTitle,
        });
        return { paymentId, clientSecret: intent.client_secret, isDev: false, plan: input.plan, amount };
      }),

    confirmPayment: publicProcedure
      .input(z.object({
        paymentId: z.number(),
        stripePaymentIntentId: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.updatePaymentStatus(input.paymentId, "succeeded", input.stripePaymentIntentId);
        const payment = await db.getPaymentById(input.paymentId);
        return { success: true, payment };
      }),

    history: publicProcedure
      .input(z.object({ userId: z.string() }))
      .query(async ({ input }) => db.getUserPayments(input.userId)),
  }),

  messages: router({
    getOrCreateConversation: publicProcedure
      .input(z.object({
        id: z.string(),
        userId: z.string(),
        advertiserId: z.string(),
        listingId: z.string(),
        listingTitle: z.string(),
      }))
      .mutation(async ({ input }) => {
        return db.getOrCreateConversation(input.id, input.userId, input.advertiserId, input.listingId, input.listingTitle);
      }),

    send: publicProcedure
      .input(z.object({
        conversationId: z.string(),
        senderId: z.string(),
        text: z.string().min(1).max(2000),
      }))
      .mutation(async ({ input }) => {
        const id = await db.sendMessage({ conversationId: input.conversationId, senderId: input.senderId, text: input.text });
        return { id };
      }),

    poll: publicProcedure
      .input(z.object({
        conversationId: z.string(),
        afterId: z.number().optional(),
      }))
      .query(async ({ input }) => db.getMessages(input.conversationId, input.afterId)),

    getAll: publicProcedure
      .input(z.object({ conversationId: z.string() }))
      .query(async ({ input }) => db.getMessages(input.conversationId)),

    markRead: publicProcedure
      .input(z.object({ conversationId: z.string() }))
      .mutation(async ({ input }) => {
        await db.markMessagesRead(input.conversationId);
        return { success: true };
      }),

    complete: publicProcedure
      .input(z.object({ conversationId: z.string() }))
      .mutation(async ({ input }) => {
        await db.completeConversation(input.conversationId);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
