import * as ImagePicker from "expo-image-picker";
import { useRouter } from "expo-router";
import { useState } from "react";
import {
  Alert,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { scheduleListingExpiryNotification } from "@/lib/notifications";
import { useAppStore } from "@/lib/store";

const POST_CATEGORIES = ["Dating", "Hookups", "Companionship", "Events", "Other"] as const;
const SAMPLE_TAGS = [
  "Dinner dates","Travel","Nightlife","Discreet","Events",
  "Companionship","Spontaneous","No strings","Fun","Upscale","Warm","Genuine",
];
const TOTAL_STEPS = 4;

export default function PostScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { state, dispatch } = useAppStore();

  const [step, setStep] = useState(1);
  const [category, setCategory] = useState<string>("Dating");
  const [photos, setPhotos] = useState<string[]>([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState(state.profile.location || "");
  const [age, setAge] = useState(String(state.profile.age || ""));
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [customTag, setCustomTag] = useState("");

  const canAdvance = () => {
    if (step === 1) return !!category;
    if (step === 2) return photos.length > 0;
    if (step === 3) return title.trim().length > 0 && description.trim().length > 10;
    return true;
  };

  const pickPhoto = async () => {
    if (photos.length >= 6) {
      Alert.alert("Limit reached", "You can add up to 6 photos.");
      return;
    }
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Permission needed", "Please allow access to your photo library in Settings.");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [3, 4],
      quality: 0.8,
    });
    if (!result.canceled && result.assets[0]) {
      setPhotos((prev) => [...prev, result.assets[0].uri]);
    }
  };

  const takePhoto = async () => {
    if (photos.length >= 6) {
      Alert.alert("Limit reached", "You can add up to 6 photos.");
      return;
    }
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Permission needed", "Please allow camera access in Settings.");
      return;
    }
    const result = await ImagePicker.launchCameraAsync({
      allowsEditing: true,
      aspect: [3, 4],
      quality: 0.8,
    });
    if (!result.canceled && result.assets[0]) {
      setPhotos((prev) => [...prev, result.assets[0].uri]);
    }
  };

  const removePhoto = (uri: string) => {
    setPhotos((prev) => prev.filter((p) => p !== uri));
  };

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const addCustomTag = () => {
    const t = customTag.trim();
    if (t && !selectedTags.includes(t) && selectedTags.length < 8) {
      setSelectedTags((prev) => [...prev, t]);
      setCustomTag("");
    }
  };

  const handlePublish = () => {
    const hasActiveSub =
      state.profile.subscriptionPlan !== "none" &&
      state.profile.subscriptionExpiry &&
      new Date(state.profile.subscriptionExpiry) > new Date();

    if (!hasActiveSub) {
      router.push({
        pathname: "/paywall",
        params: {
          pendingTitle: title.trim(),
          pendingDesc: description.trim(),
          pendingCategory: category,
          pendingPhotos: JSON.stringify(photos),
          pendingLocation: location.trim(),
          pendingAge: age.trim(),
          pendingTags: JSON.stringify(selectedTags),
        },
      });
      return;
    }
    doPublish("monthly");
  };

  const doPublish = (planType: "single" | "weekly" | "monthly") => {
    const now = Date.now();
    const expiryMs =
      planType === "monthly" ? 30 * 86400000 :
      planType === "weekly" ? 7 * 86400000 : 86400000;
    const expiresAt = new Date(now + expiryMs).toISOString();

    const newListing = {
      id: `l_${now}`,
      userId: "me",
      userName: state.profile.displayName,
      userAvatar: state.profile.avatar,
      userRating: state.profile.averageRating,
      userReviewCount: state.profile.reviewCount,
      userVerified: state.profile.isVerified,
      title: title.trim(),
      description: description.trim(),
      category: category as any,
      photos: photos.length > 0 ? photos : [state.profile.avatar],
      location: location.trim() || state.profile.location,
      age: parseInt(age) || state.profile.age,
      tags: selectedTags,
      isOnline: true,
      isFeatured: planType === "monthly",
      createdAt: new Date(now).toISOString(),
      expiresAt,
      isDeleted: false,
      planType,
    };

    dispatch({ type: "ADD_LISTING", payload: newListing });
    scheduleListingExpiryNotification(title.trim(), expiresAt);

    const durationLabel =
      planType === "single" ? "24 hours" :
      planType === "weekly" ? "7 days" : "30 days";

    Alert.alert(
      "🎉 Ad Published!",
      `Your listing is now live for ${durationLabel}.`,
      [{ text: "View My Ads", onPress: () => router.replace("/(tabs)/profile") }]
    );

    setStep(1);
    setCategory("Dating");
    setPhotos([]);
    setTitle("");
    setDescription("");
    setSelectedTags([]);
    setLocation(state.profile.location || "");
    setAge(String(state.profile.age || ""));
  };

  const handleNext = () => {
    if (!canAdvance()) {
      Alert.alert(
        "Required",
        step === 2 ? "Please add at least one photo." : "Please fill in all required fields."
      );
      return;
    }
    if (step < TOTAL_STEPS) {
      setStep(step + 1);
    } else {
      handlePublish();
    }
  };

  const stepLabel = ["Category", "Photos", "Details", "Preview"][step - 1];

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Post an Ad</Text>
        <Text style={styles.stepIndicator}>Step {step} of {TOTAL_STEPS} — {stepLabel}</Text>
      </View>

      {/* Progress bar */}
      <View style={styles.progressBar}>
        <View style={[styles.progressFill, { width: `${(step / TOTAL_STEPS) * 100}%` as any }]} />
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>

        {/* ── Step 1: Category ── */}
        {step === 1 && (
          <View style={styles.stepContent}>
            <Text style={styles.stepTitle}>Choose a Category</Text>
            <Text style={styles.stepSubtitle}>What best describes your ad?</Text>
            <View style={styles.categoryGrid}>
              {POST_CATEGORIES.map((cat) => (
                <Pressable
                  key={cat}
                  onPress={() => setCategory(cat)}
                  style={[styles.categoryCard, category === cat && styles.categoryCardActive]}
                >
                  <Text style={styles.categoryEmoji}>
                    {cat === "Dating" ? "💋" : cat === "Hookups" ? "🔥" : cat === "Companionship" ? "🥂" : cat === "Events" ? "🎭" : "✨"}
                  </Text>
                  <Text style={[styles.categoryCardText, category === cat && styles.categoryCardTextActive]}>
                    {cat}
                  </Text>
                </Pressable>
              ))}
            </View>

            {/* Verification prompt */}
            {state.profile.verificationStatus !== "verified" && (
              <Pressable
                onPress={() => router.push("/verify" as any)}
                style={({ pressed }) => [styles.verifyBanner, pressed && { opacity: 0.8 }]}
              >
                <IconSymbol name="checkmark.circle.fill" size={20} color="#D42B2B" />
                <View style={{ flex: 1 }}>
                  <Text style={styles.verifyTitle}>Get Verified ✦</Text>
                  <Text style={styles.verifySubtitle}>Verified advertisers get more visibility and a trust badge</Text>
                </View>
                <IconSymbol name="chevron.right" size={16} color="#7A6F6F" />
              </Pressable>
            )}
          </View>
        )}

        {/* ── Step 2: Photos ── */}
        {step === 2 && (
          <View style={styles.stepContent}>
            <Text style={styles.stepTitle}>Add Photos</Text>
            <Text style={styles.stepSubtitle}>Listings with photos get 5× more responses. Add up to 6.</Text>

            <View style={styles.photoGrid}>
              {photos.map((uri, idx) => (
                <View key={uri} style={styles.photoSlotFilled}>
                  <Image source={{ uri }} style={styles.photoThumb} />
                  {idx === 0 && (
                    <View style={styles.coverBadge}>
                      <Text style={{ color: "#fff", fontSize: 9, fontWeight: "700" }}>COVER</Text>
                    </View>
                  )}
                  <Pressable onPress={() => removePhoto(uri)} style={styles.removeBtn}>
                    <IconSymbol name="xmark.circle.fill" size={22} color="#D42B2B" />
                  </Pressable>
                </View>
              ))}
              {photos.length < 6 && (
                <View style={styles.photoAddSlot}>
                  <Pressable
                    onPress={pickPhoto}
                    style={({ pressed }) => [styles.photoAddBtn, pressed && { opacity: 0.7 }]}
                  >
                    <IconSymbol name="photo" size={26} color="#D42B2B" />
                    <Text style={styles.photoAddLabel}>Library</Text>
                  </Pressable>
                  <View style={{ width: 1, height: 40, backgroundColor: "#2A1A1A" }} />
                  <Pressable
                    onPress={takePhoto}
                    style={({ pressed }) => [styles.photoAddBtn, pressed && { opacity: 0.7 }]}
                  >
                    <IconSymbol name="camera.fill" size={26} color="#D42B2B" />
                    <Text style={styles.photoAddLabel}>Camera</Text>
                  </Pressable>
                </View>
              )}
            </View>
            <Text style={styles.photoHint}>💡 Clear, well-lit photos get 3× more responses</Text>
          </View>
        )}

        {/* ── Step 3: Details ── */}
        {step === 3 && (
          <View style={styles.stepContent}>
            <Text style={styles.stepTitle}>Ad Details</Text>

            <Text style={styles.fieldLabel}>Headline *</Text>
            <TextInput
              value={title}
              onChangeText={setTitle}
              placeholder="e.g. Looking for a genuine connection..."
              placeholderTextColor="#7A6F6F"
              style={styles.input}
              maxLength={80}
              returnKeyType="next"
            />
            <Text style={styles.charCount}>{title.length}/80</Text>

            <Text style={styles.fieldLabel}>Description *</Text>
            <TextInput
              value={description}
              onChangeText={setDescription}
              placeholder="Tell people about yourself, what you're looking for, and what makes you unique..."
              placeholderTextColor="#7A6F6F"
              style={[styles.input, styles.textArea]}
              multiline
              numberOfLines={5}
              maxLength={500}
            />
            <Text style={styles.charCount}>{description.length}/500</Text>

            <View style={{ flexDirection: "row", gap: 12 }}>
              <View style={{ flex: 1 }}>
                <Text style={styles.fieldLabel}>City / Location</Text>
                <TextInput
                  value={location}
                  onChangeText={setLocation}
                  placeholder="Miami, FL"
                  placeholderTextColor="#7A6F6F"
                  style={styles.input}
                  returnKeyType="next"
                />
              </View>
              <View style={{ width: 80 }}>
                <Text style={styles.fieldLabel}>Age</Text>
                <TextInput
                  value={age}
                  onChangeText={setAge}
                  placeholder="25"
                  placeholderTextColor="#7A6F6F"
                  style={styles.input}
                  keyboardType="number-pad"
                  maxLength={2}
                  returnKeyType="done"
                />
              </View>
            </View>

            <Text style={styles.fieldLabel}>Tags / Interests</Text>
            <View style={styles.tagsWrap}>
              {SAMPLE_TAGS.map((tag) => (
                <Pressable
                  key={tag}
                  onPress={() => toggleTag(tag)}
                  style={[styles.tagChip, selectedTags.includes(tag) && styles.tagChipActive]}
                >
                  <Text style={[styles.tagChipText, selectedTags.includes(tag) && styles.tagChipTextActive]}>
                    {tag}
                  </Text>
                </Pressable>
              ))}
            </View>
            <View style={styles.customTagRow}>
              <TextInput
                value={customTag}
                onChangeText={setCustomTag}
                placeholder="Add custom tag..."
                placeholderTextColor="#7A6F6F"
                style={[styles.input, { flex: 1, marginBottom: 0 }]}
                returnKeyType="done"
                onSubmitEditing={addCustomTag}
              />
              <Pressable onPress={addCustomTag} style={styles.addTagBtn}>
                <Text style={styles.addTagBtnText}>Add</Text>
              </Pressable>
            </View>
          </View>
        )}

        {/* ── Step 4: Preview ── */}
        {step === 4 && (
          <View style={styles.stepContent}>
            <Text style={styles.stepTitle}>Preview Your Ad</Text>
            <Text style={styles.stepSubtitle}>Here's how your ad will appear to others.</Text>

            <View style={styles.previewCard}>
              {photos.length > 0 ? (
                <Image source={{ uri: photos[0] }} style={styles.previewImage} />
              ) : (
                <View style={[styles.previewImage, { backgroundColor: "#2A1010", alignItems: "center", justifyContent: "center" }]}>
                  <Text style={{ color: "#5A4A4A", fontSize: 13 }}>No photo added</Text>
                </View>
              )}
              <View style={styles.previewOverlay} />
              <View style={styles.previewInfo}>
                <Text style={styles.previewName}>{state.profile.displayName}, {age || state.profile.age}</Text>
                <Text style={styles.previewTitle}>{title || "Your headline here"}</Text>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginTop: 6 }}>
                  <Text style={{ fontSize: 12, color: "#9A8F8F" }}>📍 {location || state.profile.location}</Text>
                  <View style={styles.catBadge}>
                    <Text style={styles.catBadgeText}>{category}</Text>
                  </View>
                </View>
              </View>
            </View>

            {/* Expiry notice */}
            <View style={styles.expiryBox}>
              <IconSymbol name="info.circle" size={16} color="#D42B2B" />
              <Text style={styles.expiryText}>
                Single post ads expire after <Text style={{ color: "#D42B2B", fontWeight: "700" }}>24 hours</Text>.
                Subscribe for longer visibility (7 or 30 days).
              </Text>
            </View>

            <View style={styles.summaryBox}>
              {[
                ["Category", category],
                ["Photos", `${photos.length} photo${photos.length !== 1 ? "s" : ""}`],
                ["Location", location || state.profile.location],
                ["Tags", selectedTags.length > 0 ? selectedTags.join(", ") : "None"],
              ].map(([label, value]) => (
                <View key={label} style={styles.summaryRow}>
                  <Text style={styles.summaryLabel}>{label}</Text>
                  <Text style={styles.summaryValue}>{value}</Text>
                </View>
              ))}
            </View>

            <View style={styles.publishNote}>
              <IconSymbol name="lock.fill" size={14} color="#D42B2B" />
              <Text style={styles.publishNoteText}>
                Publishing requires a listing plan. You'll choose your plan on the next screen.
              </Text>
            </View>
          </View>
        )}
      </ScrollView>

      {/* Navigation */}
      <View style={[styles.navBar, { paddingBottom: insets.bottom + 12 }]}>
        {step > 1 && (
          <Pressable onPress={() => setStep(step - 1)} style={styles.backButton}>
            <IconSymbol name="chevron.left" size={18} color="#F5F0F0" />
            <Text style={styles.backButtonText}>Back</Text>
          </Pressable>
        )}
        <Pressable
          onPress={handleNext}
          style={[styles.nextButton, step === 1 && { flex: 1 }]}
        >
          <Text style={styles.nextButtonText}>
            {step === TOTAL_STEPS ? "Choose Plan & Publish" : "Continue"}
          </Text>
          <IconSymbol name="arrow.right" size={18} color="#F5F0F0" />
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0A0A0A" },
  header: { paddingHorizontal: 20, paddingBottom: 8, paddingTop: 8 },
  headerTitle: { color: "#F5F0F0", fontSize: 22, fontWeight: "800" },
  stepIndicator: { color: "#7A6F6F", fontSize: 12, marginTop: 2 },
  progressBar: { height: 3, backgroundColor: "#2A1F1F", marginHorizontal: 20, borderRadius: 2, marginBottom: 16 },
  progressFill: { height: 3, backgroundColor: "#D42B2B", borderRadius: 2 },
  scrollContent: { paddingHorizontal: 20, paddingBottom: 20 },
  stepContent: { gap: 16 },
  stepTitle: { color: "#F5F0F0", fontSize: 20, fontWeight: "700" },
  stepSubtitle: { color: "#7A6F6F", fontSize: 14, marginTop: -8 },
  categoryGrid: { flexDirection: "row", flexWrap: "wrap", gap: 12 },
  categoryCard: {
    width: "47%", backgroundColor: "#161618", borderRadius: 14,
    padding: 18, alignItems: "center", gap: 8,
    borderWidth: 1, borderColor: "#2A1F1F",
  },
  categoryCardActive: { borderColor: "#D42B2B", backgroundColor: "#2A1010" },
  categoryEmoji: { fontSize: 28 },
  categoryCardText: { color: "#7A6F6F", fontSize: 14, fontWeight: "600" },
  categoryCardTextActive: { color: "#D42B2B" },
  verifyBanner: {
    flexDirection: "row", alignItems: "center", gap: 12,
    backgroundColor: "#1A0A0A", borderWidth: 1, borderColor: "#D42B2B",
    borderRadius: 12, padding: 14, marginTop: 4,
  },
  verifyTitle: { fontSize: 14, fontWeight: "700", color: "#F5F0F0" },
  verifySubtitle: { fontSize: 12, color: "#7A6F6F", marginTop: 2 },
  photoGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  photoSlotFilled: { width: 100, height: 130, borderRadius: 10, overflow: "hidden", position: "relative" },
  photoThumb: { width: "100%", height: "100%" },
  coverBadge: {
    position: "absolute", bottom: 6, left: 6,
    backgroundColor: "#D42B2B", borderRadius: 4,
    paddingHorizontal: 5, paddingVertical: 2,
  },
  removeBtn: { position: "absolute", top: 4, right: 4 },
  photoAddSlot: {
    width: 100, height: 130, borderRadius: 10,
    borderWidth: 1.5, borderColor: "#3A2A2A", borderStyle: "dashed",
    backgroundColor: "#1A0A0A", alignItems: "center", justifyContent: "space-evenly",
    flexDirection: "column",
  },
  photoAddBtn: { alignItems: "center", gap: 4, paddingVertical: 8 },
  photoAddLabel: { fontSize: 11, color: "#7A6F6F" },
  photoHint: { fontSize: 12, color: "#5A4A4A", fontStyle: "italic" },
  fieldLabel: { color: "#9A8F8F", fontSize: 13, fontWeight: "600" },
  input: {
    backgroundColor: "#161618", borderWidth: 1, borderColor: "#2A1F1F",
    borderRadius: 10, padding: 12, color: "#F5F0F0", fontSize: 14,
  },
  textArea: { height: 120, textAlignVertical: "top" },
  charCount: { color: "#5A4A4A", fontSize: 11, textAlign: "right" },
  tagsWrap: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  tagChip: {
    paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20,
    borderWidth: 1, borderColor: "#2A1F1F", backgroundColor: "#161618",
  },
  tagChipActive: { borderColor: "#D42B2B", backgroundColor: "#2A1010" },
  tagChipText: { color: "#7A6F6F", fontSize: 12, fontWeight: "600" },
  tagChipTextActive: { color: "#D42B2B" },
  customTagRow: { flexDirection: "row", gap: 8, alignItems: "center" },
  addTagBtn: {
    backgroundColor: "#161618", borderWidth: 1, borderColor: "#D42B2B",
    borderRadius: 10, paddingHorizontal: 14, paddingVertical: 12,
  },
  addTagBtnText: { color: "#D42B2B", fontWeight: "700" },
  previewCard: { height: 280, borderRadius: 16, overflow: "hidden", position: "relative" },
  previewImage: { width: "100%", height: "100%" },
  previewOverlay: {
    position: "absolute", bottom: 0, left: 0, right: 0, height: 140,
    backgroundColor: "rgba(0,0,0,0.7)",
  },
  previewInfo: { position: "absolute", bottom: 16, left: 16, right: 16 },
  previewName: { fontSize: 18, fontWeight: "800", color: "#F5F0F0" },
  previewTitle: { fontSize: 13, color: "#C0B0B0", marginTop: 2 },
  catBadge: { backgroundColor: "#D42B2B", borderRadius: 6, paddingHorizontal: 8, paddingVertical: 2 },
  catBadgeText: { fontSize: 10, fontWeight: "700", color: "#fff" },
  expiryBox: {
    flexDirection: "row", alignItems: "flex-start", gap: 8,
    backgroundColor: "#1A0A0A", borderWidth: 1, borderColor: "#3A1A1A",
    borderRadius: 10, padding: 12,
  },
  expiryText: { flex: 1, fontSize: 13, color: "#9A8F8F", lineHeight: 18 },
  summaryBox: {
    backgroundColor: "#161618", borderRadius: 12, padding: 14,
    borderWidth: 1, borderColor: "#2A1F1F",
  },
  summaryRow: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 6 },
  summaryLabel: { color: "#7A6F6F", fontSize: 13 },
  summaryValue: { color: "#F5F0F0", fontSize: 13, fontWeight: "600", flex: 1, textAlign: "right" },
  publishNote: {
    flexDirection: "row", alignItems: "flex-start", gap: 8,
    backgroundColor: "#1A0A0A", borderRadius: 10, padding: 12,
    borderWidth: 1, borderColor: "#2A1F1F",
  },
  publishNoteText: { flex: 1, color: "#7A6F6F", fontSize: 12, lineHeight: 18 },
  navBar: {
    flexDirection: "row", alignItems: "center", paddingHorizontal: 20, paddingTop: 12,
    borderTopWidth: 0.5, borderTopColor: "#2A1F1F", backgroundColor: "#0A0A0A", gap: 12,
  },
  backButton: {
    flexDirection: "row", alignItems: "center", gap: 4,
    paddingVertical: 14, paddingHorizontal: 16,
    borderRadius: 12, borderWidth: 1, borderColor: "#2A1F1F",
  },
  backButtonText: { color: "#F5F0F0", fontWeight: "600", fontSize: 15 },
  nextButton: {
    flex: 1, backgroundColor: "#D42B2B", borderRadius: 12,
    paddingVertical: 15, alignItems: "center", flexDirection: "row",
    justifyContent: "center", gap: 8,
  },
  nextButtonText: { color: "#fff", fontWeight: "800", fontSize: 16 },
});
