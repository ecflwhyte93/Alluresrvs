import AsyncStorage from "@react-native-async-storage/async-storage";
import { useRouter } from "expo-router";
import { useEffect, useRef, useState } from "react";
import {
  Alert,
  Animated,
  Dimensions,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const { width, height } = Dimensions.get("window");

const SLIDES = [
  {
    id: "welcome",
    title: "Welcome to Allure",
    subtitle: "The premium classifieds platform for social companionship and meaningful connections.",
    icon: "✦",
    bg: "#D42B2B",
  },
  {
    id: "discover",
    title: "Discover Connections",
    subtitle: "Browse verified profiles and ads from real people near you. Filter by category, location, and more.",
    icon: "🔍",
    bg: "#1A0A0A",
  },
  {
    id: "post",
    title: "Post Your Ad",
    subtitle: "Create a stunning listing in minutes. Add photos, describe yourself, and reach thousands of people.",
    icon: "📸",
    bg: "#1A0A0A",
  },
  {
    id: "safe",
    title: "Safe & Verified",
    subtitle: "Mutual ratings, photo verification, and a trusted community keep every interaction safe.",
    icon: "🛡️",
    bg: "#1A0A0A",
  },
];

export default function OnboardingScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [step, setStep] = useState(0); // 0 = slides, 1 = age gate
  const [slideIndex, setSlideIndex] = useState(0);
  const [ageConfirmed, setAgeConfirmed] = useState(false);
  const [termsAccepted, setTermsAccepted] = useState(false);
  const fadeAnim = useRef(new Animated.Value(1)).current;
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const goToSlide = (index: number) => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 0, duration: 150, useNativeDriver: true }),
      Animated.timing(scaleAnim, { toValue: 0.96, duration: 150, useNativeDriver: true }),
    ]).start(() => {
      setSlideIndex(index);
      Animated.parallel([
        Animated.timing(fadeAnim, { toValue: 1, duration: 200, useNativeDriver: true }),
        Animated.timing(scaleAnim, { toValue: 1, duration: 200, useNativeDriver: true }),
      ]).start();
    });
  };

  const handleNext = () => {
    if (slideIndex < SLIDES.length - 1) {
      goToSlide(slideIndex + 1);
    } else {
      setStep(1);
    }
  };

  const handleEnter = async () => {
    if (!ageConfirmed) {
      Alert.alert("Age Verification Required", "You must confirm you are 18 or older to use Allure.");
      return;
    }
    if (!termsAccepted) {
      Alert.alert("Terms Required", "Please accept the Terms of Service and Privacy Policy to continue.");
      return;
    }
    await AsyncStorage.setItem("allure_onboarded", "true");
    router.replace("/(tabs)");
  };

  const slide = SLIDES[slideIndex];

  if (step === 1) {
    return (
      <View style={[styles.ageContainer, { paddingTop: insets.top, paddingBottom: insets.bottom + 20 }]}>
        <View style={styles.ageContent}>
          <Text style={styles.ageLogo}>✦ ALLURE</Text>
          <Text style={styles.ageTitle}>Before You Enter</Text>
          <Text style={styles.ageSubtitle}>
            Allure contains adult-oriented content. You must be 18 years of age or older to access this platform.
          </Text>

          <View style={styles.ageWarningBox}>
            <Text style={styles.ageWarningIcon}>⚠️</Text>
            <Text style={styles.ageWarningText}>
              This platform contains content intended for adults only. By entering, you confirm you are of legal age in your jurisdiction.
            </Text>
          </View>

          {/* Age checkbox */}
          <Pressable
            onPress={() => setAgeConfirmed(!ageConfirmed)}
            style={styles.checkRow}
          >
            <View style={[styles.checkbox, ageConfirmed && styles.checkboxChecked]}>
              {ageConfirmed && <Text style={styles.checkmark}>✓</Text>}
            </View>
            <Text style={styles.checkLabel}>I confirm I am 18 years of age or older</Text>
          </Pressable>

          {/* Terms checkbox */}
          <Pressable
            onPress={() => setTermsAccepted(!termsAccepted)}
            style={styles.checkRow}
          >
            <View style={[styles.checkbox, termsAccepted && styles.checkboxChecked]}>
              {termsAccepted && <Text style={styles.checkmark}>✓</Text>}
            </View>
            <Text style={styles.checkLabel}>
              I agree to the{" "}
              <Text style={styles.linkText} onPress={() => router.push("/terms" as any)}>Terms of Service</Text>
              {" "}and{" "}
              <Text style={styles.linkText} onPress={() => router.push("/privacy" as any)}>Privacy Policy</Text>
            </Text>
          </Pressable>

          <Pressable
            onPress={handleEnter}
            style={({ pressed }) => [
              styles.enterBtn,
              (!ageConfirmed || !termsAccepted) && styles.enterBtnDisabled,
              pressed && { opacity: 0.85 },
            ]}
          >
            <Text style={styles.enterBtnText}>Enter Allure ✦</Text>
          </Pressable>

          <Pressable onPress={() => setStep(0)} style={{ marginTop: 16, alignSelf: "center" }}>
            <Text style={{ color: "#5A4F4F", fontSize: 13 }}>← Back</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top, paddingBottom: insets.bottom + 20 }]}>
      {/* Background gradient overlay */}
      <View style={StyleSheet.absoluteFillObject}>
        <View style={[styles.bgTop, { backgroundColor: slide.bg === "#D42B2B" ? "#D42B2B" : "#0A0A0A" }]} />
        <View style={styles.bgBottom} />
      </View>

      {/* Logo */}
      <Text style={styles.logo}>✦ ALLURE</Text>

      {/* Slide content */}
      <Animated.View style={[styles.slideContent, { opacity: fadeAnim, transform: [{ scale: scaleAnim }] }]}>
        <View style={styles.iconCircle}>
          <Text style={styles.slideIcon}>{slide.icon}</Text>
        </View>
        <Text style={styles.slideTitle}>{slide.title}</Text>
        <Text style={styles.slideSubtitle}>{slide.subtitle}</Text>
      </Animated.View>

      {/* Dots */}
      <View style={styles.dots}>
        {SLIDES.map((_, i) => (
          <Pressable key={i} onPress={() => goToSlide(i)}>
            <View style={[styles.dot, i === slideIndex && styles.dotActive]} />
          </Pressable>
        ))}
      </View>

      {/* CTA */}
      <View style={styles.ctaArea}>
        <Pressable
          onPress={handleNext}
          style={({ pressed }) => [styles.nextBtn, pressed && { opacity: 0.85 }]}
        >
          <Text style={styles.nextBtnText}>
            {slideIndex < SLIDES.length - 1 ? "Next →" : "Get Started ✦"}
          </Text>
        </Pressable>
        {slideIndex < SLIDES.length - 1 && (
          <Pressable onPress={() => setStep(1)} style={{ marginTop: 14, alignSelf: "center" }}>
            <Text style={styles.skipText}>Skip</Text>
          </Pressable>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0A0A0A", alignItems: "center", justifyContent: "space-between" },
  bgTop: { position: "absolute", top: 0, left: 0, right: 0, height: height * 0.35 },
  bgBottom: { position: "absolute", bottom: 0, left: 0, right: 0, top: height * 0.35, backgroundColor: "#0A0A0A" },
  logo: { color: "#F5F0F0", fontSize: 18, fontWeight: "900", letterSpacing: 4, marginTop: 16 },
  slideContent: { flex: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 36, gap: 20 },
  iconCircle: {
    width: 100, height: 100, borderRadius: 50,
    backgroundColor: "rgba(212,43,43,0.15)", borderWidth: 2, borderColor: "#D42B2B",
    alignItems: "center", justifyContent: "center",
  },
  slideIcon: { fontSize: 44 },
  slideTitle: { color: "#F5F0F0", fontSize: 28, fontWeight: "800", textAlign: "center", lineHeight: 36 },
  slideSubtitle: { color: "#9A8F8F", fontSize: 15, textAlign: "center", lineHeight: 22 },
  dots: { flexDirection: "row", gap: 8, marginBottom: 24 },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: "#3A2A2A" },
  dotActive: { width: 24, backgroundColor: "#D42B2B" },
  ctaArea: { width: "100%", paddingHorizontal: 24, paddingBottom: 8 },
  nextBtn: {
    backgroundColor: "#D42B2B", borderRadius: 16,
    paddingVertical: 16, alignItems: "center",
  },
  nextBtnText: { color: "#F5F0F0", fontSize: 17, fontWeight: "800", letterSpacing: 0.5 },
  skipText: { color: "#5A4F4F", fontSize: 14 },
  // Age gate styles
  ageContainer: { flex: 1, backgroundColor: "#0A0A0A" },
  ageContent: { flex: 1, paddingHorizontal: 24, justifyContent: "center", gap: 20 },
  ageLogo: { color: "#D42B2B", fontSize: 18, fontWeight: "900", letterSpacing: 4, textAlign: "center", marginBottom: 8 },
  ageTitle: { color: "#F5F0F0", fontSize: 26, fontWeight: "800", textAlign: "center" },
  ageSubtitle: { color: "#9A8F8F", fontSize: 14, textAlign: "center", lineHeight: 21 },
  ageWarningBox: {
    flexDirection: "row", gap: 12, alignItems: "flex-start",
    backgroundColor: "#1A1010", borderRadius: 14, padding: 16,
    borderWidth: 1, borderColor: "#3A1A1A",
  },
  ageWarningIcon: { fontSize: 20 },
  ageWarningText: { flex: 1, color: "#9A8F8F", fontSize: 13, lineHeight: 19 },
  checkRow: { flexDirection: "row", alignItems: "flex-start", gap: 12 },
  checkbox: {
    width: 22, height: 22, borderRadius: 6, borderWidth: 2, borderColor: "#3A2A2A",
    alignItems: "center", justifyContent: "center", marginTop: 1,
  },
  checkboxChecked: { backgroundColor: "#D42B2B", borderColor: "#D42B2B" },
  checkmark: { color: "#F5F0F0", fontSize: 13, fontWeight: "900" },
  checkLabel: { flex: 1, color: "#C5B5B5", fontSize: 14, lineHeight: 20 },
  linkText: { color: "#D42B2B", fontWeight: "700" },
  enterBtn: {
    backgroundColor: "#D42B2B", borderRadius: 16,
    paddingVertical: 16, alignItems: "center", marginTop: 8,
  },
  enterBtnDisabled: { opacity: 0.4 },
  enterBtnText: { color: "#F5F0F0", fontSize: 17, fontWeight: "800", letterSpacing: 0.5 },
});
