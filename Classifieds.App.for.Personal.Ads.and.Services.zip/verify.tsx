import * as ImagePicker from "expo-image-picker";
import { useRouter } from "expo-router";
import { useState } from "react";
import {
  Alert,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useAppStore } from "@/lib/store";

type VerifyStep = "intro" | "selfie" | "id" | "review" | "pending";

export default function VerifyScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { state, dispatch } = useAppStore();

  const [step, setStep] = useState<VerifyStep>("intro");
  const [selfieUri, setSelfieUri] = useState<string | null>(null);
  const [idUri, setIdUri] = useState<string | null>(null);

  const isAlreadyVerified = state.profile.verificationStatus === "verified";
  const isPending = state.profile.verificationStatus === "pending";

  const takeSelfie = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Camera needed", "Please allow camera access to take your verification selfie.");
      return;
    }
    const result = await ImagePicker.launchCameraAsync({
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.9,
    });
    if (!result.canceled && result.assets[0]) {
      setSelfieUri(result.assets[0].uri);
    }
  };

  const pickSelfieFromLibrary = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Permission needed", "Please allow photo library access.");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.9,
    });
    if (!result.canceled && result.assets[0]) {
      setSelfieUri(result.assets[0].uri);
    }
  };

  const pickIdPhoto = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Permission needed", "Please allow photo library access.");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      allowsEditing: true,
      aspect: [16, 10],
      quality: 0.9,
    });
    if (!result.canceled && result.assets[0]) {
      setIdUri(result.assets[0].uri);
    }
  };

  const takeIdPhoto = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Camera needed", "Please allow camera access.");
      return;
    }
    const result = await ImagePicker.launchCameraAsync({
      allowsEditing: true,
      aspect: [16, 10],
      quality: 0.9,
    });
    if (!result.canceled && result.assets[0]) {
      setIdUri(result.assets[0].uri);
    }
  };

  const submitVerification = () => {
    dispatch({
      type: "SET_VERIFICATION",
      payload: {
        status: "verified", // In production this would be "pending" until reviewed
        selfie: selfieUri || undefined,
        idPhoto: idUri || undefined,
      },
    });
    setStep("pending");
  };

  if (isAlreadyVerified) {
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <IconSymbol name="chevron.left" size={22} color="#F5F0F0" />
        </Pressable>
        <View style={styles.centeredContent}>
          <View style={styles.successIcon}>
            <Text style={{ fontSize: 48 }}>✓</Text>
          </View>
          <Text style={styles.successTitle}>You're Verified!</Text>
          <Text style={styles.successSubtitle}>
            Your account has been verified. Your listings show a trust badge to potential clients.
          </Text>
          <Pressable
            onPress={() => router.back()}
            style={({ pressed }) => [styles.primaryBtn, pressed && { opacity: 0.85 }]}
          >
            <Text style={styles.primaryBtnText}>Back to Profile</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <Pressable onPress={() => (step === "intro" ? router.back() : setStep("intro"))} style={styles.backBtn}>
          <IconSymbol name="chevron.left" size={22} color="#F5F0F0" />
        </Pressable>
        <Text style={styles.headerTitle}>Get Verified</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>

        {/* ── Intro ── */}
        {step === "intro" && (
          <View style={styles.stepContent}>
            <View style={styles.iconCircle}>
              <IconSymbol name="checkmark.circle.fill" size={48} color="#D42B2B" />
            </View>
            <Text style={styles.stepTitle}>Advertiser Verification</Text>
            <Text style={styles.stepSubtitle}>
              Verification builds trust with clients and increases your ad visibility. Verified advertisers receive a badge on all their listings.
            </Text>

            <View style={styles.benefitsList}>
              {[
                ["✦", "Verified badge on all your ads"],
                ["✦", "Higher placement in search results"],
                ["✦", "Increased client trust and safety"],
                ["✦", "Access to featured ad slots"],
              ].map(([icon, text]) => (
                <View key={text} style={styles.benefitRow}>
                  <Text style={{ color: "#D42B2B", fontSize: 14 }}>{icon}</Text>
                  <Text style={styles.benefitText}>{text}</Text>
                </View>
              ))}
            </View>

            <View style={styles.safetyBox}>
              <IconSymbol name="lock.fill" size={16} color="#D42B2B" />
              <Text style={styles.safetyText}>
                Your documents are encrypted and used only for verification. They are never shared with other users.
              </Text>
            </View>

            <View style={styles.stepsPreview}>
              <Text style={styles.stepsPreviewTitle}>What you'll need:</Text>
              {[
                "A clear selfie photo of your face",
                "A government-issued photo ID (driver's license, passport, or state ID)",
              ].map((item, i) => (
                <View key={i} style={styles.stepsPreviewRow}>
                  <View style={styles.stepNum}>
                    <Text style={{ color: "#D42B2B", fontSize: 12, fontWeight: "700" }}>{i + 1}</Text>
                  </View>
                  <Text style={styles.stepsPreviewText}>{item}</Text>
                </View>
              ))}
            </View>

            <Pressable
              onPress={() => setStep("selfie")}
              style={({ pressed }) => [styles.primaryBtn, pressed && { opacity: 0.85 }]}
            >
              <Text style={styles.primaryBtnText}>Start Verification →</Text>
            </Pressable>
          </View>
        )}

        {/* ── Selfie ── */}
        {step === "selfie" && (
          <View style={styles.stepContent}>
            <Text style={styles.stepBadge}>Step 1 of 2</Text>
            <Text style={styles.stepTitle}>Take a Selfie</Text>
            <Text style={styles.stepSubtitle}>
              Take a clear photo of your face. Make sure your face is fully visible and well-lit.
            </Text>

            {selfieUri ? (
              <View style={styles.photoPreview}>
                <Image source={{ uri: selfieUri }} style={styles.selfiePreview} />
                <Pressable
                  onPress={() => setSelfieUri(null)}
                  style={styles.retakeBtn}
                >
                  <Text style={styles.retakeBtnText}>Retake</Text>
                </Pressable>
              </View>
            ) : (
              <View style={styles.photoPlaceholder}>
                <View style={styles.faceSilhouette}>
                  <Text style={{ fontSize: 64 }}>👤</Text>
                </View>
                <Text style={styles.placeholderText}>No selfie taken yet</Text>
              </View>
            )}

            <View style={styles.actionRow}>
              <Pressable
                onPress={takeSelfie}
                style={({ pressed }) => [styles.actionBtn, pressed && { opacity: 0.8 }]}
              >
                <IconSymbol name="camera.fill" size={22} color="#D42B2B" />
                <Text style={styles.actionBtnText}>Take Selfie</Text>
              </Pressable>
              <Pressable
                onPress={pickSelfieFromLibrary}
                style={({ pressed }) => [styles.actionBtn, pressed && { opacity: 0.8 }]}
              >
                <IconSymbol name="photo" size={22} color="#D42B2B" />
                <Text style={styles.actionBtnText}>From Library</Text>
              </Pressable>
            </View>

            <View style={styles.tipBox}>
              <Text style={styles.tipTitle}>Tips for a good selfie:</Text>
              <Text style={styles.tipText}>• Face the camera directly with good lighting</Text>
              <Text style={styles.tipText}>• Remove sunglasses or hats</Text>
              <Text style={styles.tipText}>• Plain background preferred</Text>
            </View>

            <Pressable
              onPress={() => selfieUri ? setStep("id") : Alert.alert("Required", "Please take or upload a selfie to continue.")}
              style={({ pressed }) => [styles.primaryBtn, !selfieUri && styles.primaryBtnDisabled, pressed && { opacity: 0.85 }]}
            >
              <Text style={styles.primaryBtnText}>Continue →</Text>
            </Pressable>
          </View>
        )}

        {/* ── ID ── */}
        {step === "id" && (
          <View style={styles.stepContent}>
            <Text style={styles.stepBadge}>Step 2 of 2</Text>
            <Text style={styles.stepTitle}>Photo ID</Text>
            <Text style={styles.stepSubtitle}>
              Upload a photo of your government-issued ID. We accept driver's licenses, passports, and state IDs.
            </Text>

            {idUri ? (
              <View style={styles.photoPreview}>
                <Image source={{ uri: idUri }} style={styles.idPreview} />
                <Pressable
                  onPress={() => setIdUri(null)}
                  style={styles.retakeBtn}
                >
                  <Text style={styles.retakeBtnText}>Retake</Text>
                </Pressable>
              </View>
            ) : (
              <View style={[styles.photoPlaceholder, { height: 160 }]}>
                <IconSymbol name="person.fill" size={40} color="#3A2A2A" />
                <Text style={styles.placeholderText}>No ID uploaded yet</Text>
              </View>
            )}

            <View style={styles.actionRow}>
              <Pressable
                onPress={takeIdPhoto}
                style={({ pressed }) => [styles.actionBtn, pressed && { opacity: 0.8 }]}
              >
                <IconSymbol name="camera.fill" size={22} color="#D42B2B" />
                <Text style={styles.actionBtnText}>Take Photo</Text>
              </Pressable>
              <Pressable
                onPress={pickIdPhoto}
                style={({ pressed }) => [styles.actionBtn, pressed && { opacity: 0.8 }]}
              >
                <IconSymbol name="photo" size={22} color="#D42B2B" />
                <Text style={styles.actionBtnText}>Upload ID</Text>
              </Pressable>
            </View>

            <View style={styles.safetyBox}>
              <IconSymbol name="lock.fill" size={14} color="#D42B2B" />
              <Text style={styles.safetyText}>
                Your ID is encrypted and only used to verify your age and identity. It is never visible to other users.
              </Text>
            </View>

            <Pressable
              onPress={() => idUri ? setStep("review") : Alert.alert("Required", "Please upload your ID to continue.")}
              style={({ pressed }) => [styles.primaryBtn, !idUri && styles.primaryBtnDisabled, pressed && { opacity: 0.85 }]}
            >
              <Text style={styles.primaryBtnText}>Review & Submit →</Text>
            </Pressable>
          </View>
        )}

        {/* ── Review ── */}
        {step === "review" && (
          <View style={styles.stepContent}>
            <Text style={styles.stepTitle}>Review & Submit</Text>
            <Text style={styles.stepSubtitle}>
              Please review your photos before submitting for verification.
            </Text>

            <View style={styles.reviewGrid}>
              <View style={styles.reviewItem}>
                <Text style={styles.reviewLabel}>Selfie</Text>
                {selfieUri && (
                  <Image source={{ uri: selfieUri }} style={styles.reviewThumb} />
                )}
                <Pressable onPress={() => setStep("selfie")} style={styles.changeBtn}>
                  <Text style={styles.changeBtnText}>Change</Text>
                </Pressable>
              </View>
              <View style={styles.reviewItem}>
                <Text style={styles.reviewLabel}>Photo ID</Text>
                {idUri && (
                  <Image source={{ uri: idUri }} style={styles.reviewThumbWide} />
                )}
                <Pressable onPress={() => setStep("id")} style={styles.changeBtn}>
                  <Text style={styles.changeBtnText}>Change</Text>
                </Pressable>
              </View>
            </View>

            <View style={styles.consentBox}>
              <Text style={styles.consentText}>
                By submitting, you confirm that you are at least 18 years old, the photos are of you, and you agree to our Terms of Service and Verification Policy.
              </Text>
            </View>

            <Pressable
              onPress={submitVerification}
              style={({ pressed }) => [styles.primaryBtn, pressed && { opacity: 0.85 }]}
            >
              <Text style={styles.primaryBtnText}>Submit for Verification ✓</Text>
            </Pressable>
          </View>
        )}

        {/* ── Pending ── */}
        {step === "pending" && (
          <View style={styles.centeredContent}>
            <View style={styles.successIcon}>
              <Text style={{ fontSize: 48 }}>✓</Text>
            </View>
            <Text style={styles.successTitle}>Verification Submitted!</Text>
            <Text style={styles.successSubtitle}>
              Your verification has been approved. Your verified badge is now active on all your listings.
            </Text>
            <Pressable
              onPress={() => router.replace("/(tabs)/profile")}
              style={({ pressed }) => [styles.primaryBtn, pressed && { opacity: 0.85 }]}
            >
              <Text style={styles.primaryBtnText}>Back to Profile</Text>
            </Pressable>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0A0A0A" },
  header: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 0.5, borderBottomColor: "#2A1A1A",
  },
  backBtn: { padding: 8 },
  headerTitle: { fontSize: 18, fontWeight: "700", color: "#F5F0F0" },
  scrollContent: { padding: 24, paddingBottom: 60 },
  stepContent: { gap: 20 },
  iconCircle: { alignItems: "center", paddingVertical: 8 },
  stepBadge: {
    alignSelf: "flex-start", backgroundColor: "#2A1010",
    borderRadius: 20, paddingHorizontal: 12, paddingVertical: 4,
    color: "#D42B2B", fontSize: 12, fontWeight: "700",
  },
  stepTitle: { fontSize: 22, fontWeight: "800", color: "#F5F0F0" },
  stepSubtitle: { fontSize: 14, color: "#9A8F8F", lineHeight: 20 },
  benefitsList: { gap: 12 },
  benefitRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  benefitText: { fontSize: 14, color: "#C0B0B0", flex: 1 },
  safetyBox: {
    flexDirection: "row", alignItems: "flex-start", gap: 10,
    backgroundColor: "#1A0A0A", borderWidth: 1, borderColor: "#3A1A1A",
    borderRadius: 10, padding: 12,
  },
  safetyText: { flex: 1, fontSize: 12, color: "#9A8F8F", lineHeight: 18 },
  stepsPreview: { gap: 12 },
  stepsPreviewTitle: { fontSize: 14, fontWeight: "700", color: "#F5F0F0" },
  stepsPreviewRow: { flexDirection: "row", alignItems: "flex-start", gap: 12 },
  stepNum: {
    width: 24, height: 24, borderRadius: 12,
    backgroundColor: "#2A1010", borderWidth: 1, borderColor: "#D42B2B",
    alignItems: "center", justifyContent: "center",
  },
  stepsPreviewText: { flex: 1, fontSize: 14, color: "#C0B0B0", lineHeight: 20 },
  photoPreview: { alignItems: "center", gap: 12 },
  selfiePreview: { width: 200, height: 200, borderRadius: 100, borderWidth: 3, borderColor: "#D42B2B" },
  idPreview: { width: "100%", height: 180, borderRadius: 12, borderWidth: 2, borderColor: "#D42B2B" },
  retakeBtn: {
    paddingHorizontal: 20, paddingVertical: 8,
    borderRadius: 20, borderWidth: 1, borderColor: "#D42B2B",
  },
  retakeBtnText: { color: "#D42B2B", fontWeight: "600", fontSize: 14 },
  photoPlaceholder: {
    height: 200, backgroundColor: "#1A0A0A", borderRadius: 12,
    borderWidth: 1.5, borderColor: "#2A1A1A", borderStyle: "dashed",
    alignItems: "center", justifyContent: "center", gap: 12,
  },
  faceSilhouette: { opacity: 0.3 },
  placeholderText: { color: "#5A4A4A", fontSize: 13 },
  actionRow: { flexDirection: "row", gap: 12 },
  actionBtn: {
    flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 8, backgroundColor: "#1A0A0A", borderWidth: 1, borderColor: "#D42B2B",
    borderRadius: 12, paddingVertical: 14,
  },
  actionBtnText: { color: "#F5F0F0", fontWeight: "600", fontSize: 14 },
  tipBox: {
    backgroundColor: "#1A0A0A", borderRadius: 10, padding: 14,
    borderWidth: 1, borderColor: "#2A1A1A", gap: 4,
  },
  tipTitle: { color: "#F5F0F0", fontSize: 13, fontWeight: "700", marginBottom: 4 },
  tipText: { color: "#9A8F8F", fontSize: 12, lineHeight: 18 },
  primaryBtn: {
    backgroundColor: "#D42B2B", borderRadius: 12,
    paddingVertical: 16, alignItems: "center",
  },
  primaryBtnDisabled: { backgroundColor: "#4A1A1A", opacity: 0.6 },
  primaryBtnText: { color: "#fff", fontWeight: "800", fontSize: 16 },
  reviewGrid: { gap: 16 },
  reviewItem: { gap: 8 },
  reviewLabel: { fontSize: 13, fontWeight: "700", color: "#9A8F8F" },
  reviewThumb: { width: 120, height: 120, borderRadius: 60, borderWidth: 2, borderColor: "#D42B2B" },
  reviewThumbWide: { width: "100%", height: 160, borderRadius: 10, borderWidth: 2, borderColor: "#D42B2B" },
  changeBtn: {
    alignSelf: "flex-start", paddingHorizontal: 14, paddingVertical: 6,
    borderRadius: 20, borderWidth: 1, borderColor: "#3A2A2A",
  },
  changeBtnText: { color: "#9A8F8F", fontSize: 12, fontWeight: "600" },
  consentBox: {
    backgroundColor: "#1A0A0A", borderRadius: 10, padding: 14,
    borderWidth: 1, borderColor: "#2A1A1A",
  },
  consentText: { color: "#7A6F6F", fontSize: 12, lineHeight: 18 },
  centeredContent: { flex: 1, alignItems: "center", paddingTop: 60, gap: 20 },
  successIcon: {
    width: 100, height: 100, borderRadius: 50,
    backgroundColor: "#1A0A0A", borderWidth: 3, borderColor: "#D42B2B",
    alignItems: "center", justifyContent: "center",
  },
  successTitle: { fontSize: 24, fontWeight: "800", color: "#F5F0F0", textAlign: "center" },
  successSubtitle: { fontSize: 14, color: "#9A8F8F", textAlign: "center", lineHeight: 20, paddingHorizontal: 20 },
});
