import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { SymbolWeight, SymbolViewProps } from "expo-symbols";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

type IconMapping = Record<SymbolViewProps["name"], ComponentProps<typeof MaterialIcons>["name"]>;
type IconSymbolName = keyof typeof MAPPING;

const MAPPING = {
  // Navigation tabs
  "house.fill": "local-fire-department",
  "plus.circle.fill": "add-circle",
  "message.fill": "chat-bubble",
  "person.fill": "person",
  // UI icons
  "paperplane.fill": "send",
  "chevron.left.forwardslash.chevron.right": "code",
  "chevron.right": "chevron-right",
  "chevron.left": "chevron-left",
  "chevron.down": "expand-more",
  "heart.fill": "favorite",
  "heart": "favorite-border",
  "star.fill": "star",
  "magnifyingglass": "search",
  "xmark": "close",
  "xmark.circle.fill": "cancel",
  "camera.fill": "camera-alt",
  "photo": "photo-library",
  "location.fill": "location-on",
  "bell.fill": "notifications",
  "gear": "settings",
  "square.and.arrow.up": "share",
  "flag.fill": "flag",
  "trash.fill": "delete",
  "pencil": "edit",
  "checkmark": "check",
  "checkmark.circle.fill": "check-circle",
  "lock.fill": "lock",
  "sparkles": "auto-awesome",
  "arrow.right": "arrow-forward",
  "ellipsis": "more-horiz",
  "info.circle": "info",
  "eye.fill": "visibility",
  "eye.slash.fill": "visibility-off",
  // Missing icons — added in audit
  "checkmark.seal.fill": "verified",
  "doc.text.fill": "description",
  "nosign": "block",
  "plus": "add",
  "slider.horizontal.3": "tune",
  "crown.fill": "workspace-premium",
  "star": "star-border",
  "person.2.fill": "group",
  "shield.fill": "security",
  "exclamationmark.triangle.fill": "warning",
  "arrow.left": "arrow-back",
  "arrow.up": "arrow-upward",
  "checkmark.seal": "verified-user",
  "map.fill": "map",
  "clock.fill": "access-time",
  "flame.fill": "local-fire-department",
  "dollarsign.circle.fill": "monetization-on",
  "creditcard.fill": "credit-card",
  "photo.fill": "image",
  "person.crop.circle.fill": "account-circle",
  "bubble.left.fill": "chat",
  "square.and.pencil": "edit-note",
  "minus.circle.fill": "remove-circle",
  "ellipsis.circle": "more-vert",
  "line.3.horizontal.decrease.circle": "filter-list",
} as IconMapping;

export function IconSymbol({
  name,
  size = 24,
  color,
  style,
}: {
  name: IconSymbolName;
  size?: number;
  color: string | OpaqueColorValue;
  style?: StyleProp<TextStyle>;
  weight?: SymbolWeight;
}) {
  return <MaterialIcons color={color} size={size} name={MAPPING[name]} style={style} />;
}
