import React, { createContext, useContext, useEffect, useReducer } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  Conversation,
  Listing,
  MOCK_CONVERSATIONS,
  MOCK_LISTINGS,
  MOCK_MY_PROFILE,
  Message,
  Review,
  UserProfile,
} from "./data";

// ─── State ────────────────────────────────────────────────────────────────────

export interface AppState {
  listings: Listing[];
  conversations: Conversation[];
  profile: UserProfile;
  isLoaded: boolean;
}

const initialState: AppState = {
  listings: MOCK_LISTINGS,
  conversations: MOCK_CONVERSATIONS,
  profile: MOCK_MY_PROFILE,
  isLoaded: false,
};

// ─── Actions ──────────────────────────────────────────────────────────────────

type Action =
  | { type: "LOAD"; payload: Partial<AppState> }
  | { type: "ADD_LISTING"; payload: Listing }
  | { type: "DELETE_LISTING"; payload: string }
  | { type: "TOGGLE_FAVORITE"; payload: string }
  | { type: "UPDATE_PROFILE"; payload: Partial<UserProfile> }
  | { type: "SET_SUBSCRIPTION"; payload: { plan: UserProfile["subscriptionPlan"]; expiry: string | null } }
  | { type: "SEND_MESSAGE"; payload: { conversationId: string; text: string } }
  | { type: "START_CONVERSATION"; payload: { listing: Listing } }
  | { type: "MARK_READ"; payload: string }
  | { type: "COMPLETE_CONVERSATION"; payload: string }
  | { type: "SUBMIT_REVIEW"; payload: { conversationId: string; review: Review } }
  | { type: "SOFT_DELETE_LISTING"; payload: string }
  | { type: "EXPIRE_LISTINGS" }
  | { type: "SET_VERIFICATION"; payload: { status: UserProfile["verificationStatus"]; selfie?: string; idPhoto?: string } };

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case "LOAD":
      return { ...state, ...action.payload, isLoaded: true };

    case "ADD_LISTING":
      return { ...state, listings: [action.payload, ...state.listings] };

    case "DELETE_LISTING":
      return { ...state, listings: state.listings.filter((l) => l.id !== action.payload) };

    case "SOFT_DELETE_LISTING":
      return {
        ...state,
        listings: state.listings.map((l) =>
          l.id === action.payload ? { ...l, isDeleted: true } : l
        ),
      };

    case "EXPIRE_LISTINGS": {
      const now = Date.now();
      return {
        ...state,
        listings: state.listings.map((l) =>
          !l.isDeleted && new Date(l.expiresAt).getTime() < now
            ? { ...l, isDeleted: true }
            : l
        ),
      };
    }

    case "SET_VERIFICATION":
      return {
        ...state,
        profile: {
          ...state.profile,
          verificationStatus: action.payload.status,
          verificationSelfie: action.payload.selfie,
          verificationId: action.payload.idPhoto,
          isVerified: action.payload.status === "verified",
        },
      };

    case "TOGGLE_FAVORITE": {
      const favs = state.profile.favoriteIds;
      const newFavs = favs.includes(action.payload)
        ? favs.filter((id) => id !== action.payload)
        : [...favs, action.payload];
      return { ...state, profile: { ...state.profile, favoriteIds: newFavs } };
    }

    case "UPDATE_PROFILE":
      return { ...state, profile: { ...state.profile, ...action.payload } };

    case "SET_SUBSCRIPTION":
      return {
        ...state,
        profile: {
          ...state.profile,
          subscriptionPlan: action.payload.plan,
          subscriptionExpiry: action.payload.expiry,
        },
      };

    case "SEND_MESSAGE": {
      const msg: Message = {
        id: `msg_${Date.now()}`,
        senderId: "me",
        text: action.payload.text,
        timestamp: new Date().toISOString(),
      };
      return {
        ...state,
        conversations: state.conversations.map((c) =>
          c.id === action.payload.conversationId
            ? { ...c, messages: [...c.messages, msg], lastMessageAt: msg.timestamp }
            : c
        ),
      };
    }

    case "START_CONVERSATION": {
      const { listing } = action.payload;
      const existing = state.conversations.find((c) => c.participantId === listing.userId);
      if (existing) return state;
      const newConv: Conversation = {
        id: `conv_${Date.now()}`,
        participantId: listing.userId,
        participantName: listing.userName,
        participantAvatar: listing.userAvatar,
        listingId: listing.id,
        listingTitle: listing.title,
        messages: [],
        unreadCount: 0,
        lastMessageAt: new Date().toISOString(),
        isCompleted: false,
        myRatingGiven: false,
      };
      return { ...state, conversations: [newConv, ...state.conversations] };
    }

    case "MARK_READ":
      return {
        ...state,
        conversations: state.conversations.map((c) =>
          c.id === action.payload ? { ...c, unreadCount: 0 } : c
        ),
      };

    case "COMPLETE_CONVERSATION":
      return {
        ...state,
        conversations: state.conversations.map((c) =>
          c.id === action.payload ? { ...c, isCompleted: true } : c
        ),
      };

    case "SUBMIT_REVIEW": {
      const { conversationId, review } = action.payload;
      const updatedProfile = {
        ...state.profile,
        reviews: [...state.profile.reviews, review],
        reviewCount: state.profile.reviewCount + 1,
        averageRating:
          (state.profile.averageRating * state.profile.reviewCount + review.rating) /
          (state.profile.reviewCount + 1),
      };
      return {
        ...state,
        profile: updatedProfile,
        conversations: state.conversations.map((c) =>
          c.id === conversationId ? { ...c, myRatingGiven: true } : c
        ),
      };
    }

    default:
      return state;
  }
}

// ─── Context ──────────────────────────────────────────────────────────────────

interface AppContextValue {
  state: AppState;
  dispatch: React.Dispatch<Action>;
}

export const AppContext = createContext<AppContextValue>({
  state: initialState,
  dispatch: () => {},
});

const STORAGE_KEY = "allure_app_state_v1";

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  // Load persisted state on mount
  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((raw) => {
      if (raw) {
        try {
          const saved = JSON.parse(raw);
          dispatch({ type: "LOAD", payload: saved });
        } catch {
          dispatch({ type: "LOAD", payload: {} });
        }
      } else {
        dispatch({ type: "LOAD", payload: {} });
      }
    });
  }, []);

  // Persist state on every change
  useEffect(() => {
    if (!state.isLoaded) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify({
      listings: state.listings,
      conversations: state.conversations,
      profile: state.profile,
    }));
  }, [state]);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppStore() {
  return useContext(AppContext);
}
