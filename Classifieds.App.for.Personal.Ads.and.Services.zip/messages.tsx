import { useRouter } from "expo-router";
import {
  FlatList,
  Image,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useAppStore } from "@/lib/store";

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "now";
  if (mins < 60) return `${mins}m`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h`;
  return `${Math.floor(hrs / 24)}d`;
}

export default function MessagesScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { state } = useAppStore();

  const sorted = [...state.conversations].sort(
    (a, b) => new Date(b.lastMessageAt).getTime() - new Date(a.lastMessageAt).getTime()
  );

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Messages</Text>
        {sorted.length > 0 && (
          <View style={styles.countBadge}>
            <Text style={styles.countText}>{sorted.length}</Text>
          </View>
        )}
      </View>

      <FlatList
        data={sorted}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyIcon}>💬</Text>
            <Text style={styles.emptyTitle}>No messages yet</Text>
            <Text style={styles.emptySubtext}>
              Browse listings and send a message to start a conversation.
            </Text>
            <Pressable
              onPress={() => router.push("/")}
              style={styles.browseBtn}
            >
              <Text style={styles.browseBtnText}>Browse Listings</Text>
            </Pressable>
          </View>
        }
        renderItem={({ item }) => {
          const lastMsg = item.messages[item.messages.length - 1];
          return (
            <Pressable
              onPress={() => router.push({ pathname: "/chat/[id]", params: { id: item.id } })}
              style={({ pressed }) => [styles.convRow, pressed && { opacity: 0.75 }]}
            >
              <View style={styles.avatarWrap}>
                <Image source={{ uri: item.participantAvatar }} style={styles.avatar} />
                {item.unreadCount > 0 && (
                  <View style={styles.unreadDot}>
                    <Text style={styles.unreadDotText}>{item.unreadCount}</Text>
                  </View>
                )}
              </View>
              <View style={styles.convInfo}>
                <View style={styles.convTopRow}>
                  <Text style={styles.convName}>{item.participantName}</Text>
                  <Text style={styles.convTime}>{timeAgo(item.lastMessageAt)}</Text>
                </View>
                <Text style={styles.convListing} numberOfLines={1}>
                  Re: {item.listingTitle}
                </Text>
                <Text
                  style={[styles.convLastMsg, item.unreadCount > 0 && styles.convLastMsgUnread]}
                  numberOfLines={1}
                >
                  {lastMsg
                    ? (lastMsg.senderId === "me" ? "You: " : "") + lastMsg.text
                    : "Start the conversation..."}
                </Text>
              </View>
              {item.isCompleted && !item.myRatingGiven && (
                <Pressable
                  onPress={() => router.push({ pathname: "/rate/[conversationId]", params: { conversationId: item.id } })}
                  style={styles.rateBtn}
                >
                  <Text style={styles.rateBtnText}>Rate</Text>
                </Pressable>
              )}
            </Pressable>
          );
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0A0A0A" },
  header: {
    paddingHorizontal: 20, paddingBottom: 16, paddingTop: 8,
    flexDirection: "row", alignItems: "center", gap: 10,
  },
  headerTitle: { color: "#F5F0F0", fontSize: 26, fontWeight: "800" },
  countBadge: {
    backgroundColor: "#D42B2B", borderRadius: 12,
    paddingHorizontal: 8, paddingVertical: 3,
  },
  countText: { color: "#F5F0F0", fontSize: 12, fontWeight: "700" },
  listContent: { paddingHorizontal: 16, paddingBottom: 100 },
  convRow: {
    flexDirection: "row", alignItems: "center", gap: 14,
    paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: "#1A1A1A",
  },
  avatarWrap: { position: "relative" },
  avatar: { width: 54, height: 54, borderRadius: 27, borderWidth: 2, borderColor: "#2A1F1F" },
  unreadDot: {
    position: "absolute", top: -2, right: -2,
    backgroundColor: "#D42B2B", borderRadius: 10,
    minWidth: 18, height: 18, alignItems: "center", justifyContent: "center",
    paddingHorizontal: 4,
  },
  unreadDotText: { color: "#F5F0F0", fontSize: 10, fontWeight: "800" },
  convInfo: { flex: 1 },
  convTopRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  convName: { color: "#F5F0F0", fontSize: 15, fontWeight: "700" },
  convTime: { color: "#7A6F6F", fontSize: 11 },
  convListing: { color: "#D42B2B", fontSize: 11, marginTop: 2 },
  convLastMsg: { color: "#7A6F6F", fontSize: 13, marginTop: 3 },
  convLastMsgUnread: { color: "#C5B8B8", fontWeight: "600" },
  rateBtn: {
    backgroundColor: "#2A1010", borderRadius: 10,
    paddingHorizontal: 12, paddingVertical: 7,
    borderWidth: 1, borderColor: "#D42B2B",
  },
  rateBtnText: { color: "#D42B2B", fontSize: 12, fontWeight: "700" },
  emptyState: { alignItems: "center", paddingTop: 80, gap: 12 },
  emptyIcon: { fontSize: 48 },
  emptyTitle: { color: "#F5F0F0", fontSize: 20, fontWeight: "700" },
  emptySubtext: { color: "#7A6F6F", fontSize: 14, textAlign: "center", paddingHorizontal: 40, lineHeight: 20 },
  browseBtn: {
    backgroundColor: "#D42B2B", borderRadius: 14,
    paddingHorizontal: 28, paddingVertical: 14, marginTop: 8,
  },
  browseBtnText: { color: "#F5F0F0", fontSize: 15, fontWeight: "700" },
});
