import AsyncStorage from "@react-native-async-storage/async-storage";
import { useRouter } from "expo-router";
import { useEffect, useRef, useState } from "react";
import {
  Animated,
  FlatList,
  Image,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { Category, Listing } from "@/lib/data";
import { registerForNotificationsAsync } from "@/lib/notifications";
import { useAppStore } from "@/lib/store";

const CATEGORIES: Category[] = ["All", "Dating", "Hookups", "Companionship", "Events", "Other"];

function getExpiryLabel(expiresAt: string): { label: string; urgent: boolean } | null {
  const msLeft = new Date(expiresAt).getTime() - Date.now();
  if (msLeft <= 0) return null;
  const hoursLeft = Math.floor(msLeft / 3600000);
  const minsLeft = Math.floor((msLeft % 3600000) / 60000);
  if (hoursLeft < 2) return { label: `${hoursLeft}h ${minsLeft}m left`, urgent: true };
  if (hoursLeft < 24) return { label: `${hoursLeft}h left`, urgent: false };
  const daysLeft = Math.floor(hoursLeft / 24);
  return { label: `${daysLeft}d left`, urgent: false };
}

function StarRating({ rating, size = 12 }: { rating: number; size?: number }) {
  return (
    <View style={{ flexDirection: "row", gap: 1 }}>
      {[1, 2, 3, 4, 5].map((i) => (
        <Text key={i} style={{ fontSize: size, color: i <= Math.round(rating) ? "#D42B2B" : "#3A2A2A" }}>★</Text>
      ))}
    </View>
  );
}

function ListingCard({ item, onPress }: { item: Listing; onPress: () => void }) {
  const { state } = useAppStore();
  const isFav = state.profile.favoriteIds.includes(item.id);
  const expiry = getExpiryLabel(item.expiresAt);
  const isOwn = item.userId === "me";

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.card,
        item.isFeatured && styles.featuredCard,
        pressed && { opacity: 0.88 },
      ]}
    >
      <Image source={{ uri: item.photos[0] }} style={styles.cardImage} />
      <View style={styles.cardOverlay} />

      {item.isFeatured && (
        <View style={styles.featuredBadge}>
          <Text style={styles.featuredText}>✦ FEATURED</Text>
        </View>
      )}
      {item.isOnline && <View style={styles.onlineDot} />}
      {isFav && (
        <View style={styles.favBadge}>
          <Text style={{ fontSize: 12 }}>♥</Text>
        </View>
      )}

      {/* Expiry timer for own listings */}
      {isOwn && expiry && (
        <View style={[styles.expiryBadge, expiry.urgent && styles.expiryBadgeUrgent]}>
          <Text style={[styles.expiryBadgeText, expiry.urgent && { color: "#FF6060" }]}>
            ⏱ {expiry.label}
          </Text>
        </View>
      )}

      <View style={styles.cardInfo}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
          <Text style={styles.cardName}>{item.userName}, {item.age}</Text>
          {item.userVerified && (
            <View style={styles.verifiedBadge}>
              <Text style={styles.verifiedText}>✓</Text>
            </View>
          )}
        </View>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 2 }}>
          <StarRating rating={item.userRating} />
          <Text style={styles.reviewCount}>({item.userReviewCount})</Text>
        </View>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 3 }}>
          <Text style={styles.cardLocation} numberOfLines={1}>📍 {item.location}</Text>
          <View style={styles.categoryPill}>
            <Text style={styles.categoryPillText}>{item.category}</Text>
          </View>
        </View>
      </View>
    </Pressable>
  );
}

export default function ExploreScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { state, dispatch } = useAppStore();
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState<Category>("All");
  const [locationFilter, setLocationFilter] = useState("");
  const [showLocationFilter, setShowLocationFilter] = useState(false);
  const [hasUnreadNotif, setHasUnreadNotif] = useState(false);
  const bellAnim = useRef(new Animated.Value(0)).current;

  // Check onboarding status on mount
  useEffect(() => {
    AsyncStorage.getItem("allure_onboarded").then((val) => {
      if (!val) router.replace("/onboarding");
    });
  }, []);

  // Register for push notifications on mount
  useEffect(() => {
    registerForNotificationsAsync();
  }, []);

  // Check for unread notifications (new messages)
  useEffect(() => {
    const hasUnread = state.conversations.some((c) => c.unreadCount > 0);
    setHasUnreadNotif(hasUnread);
    if (hasUnread) {
      Animated.sequence([
        Animated.timing(bellAnim, { toValue: 1, duration: 150, useNativeDriver: true }),
        Animated.timing(bellAnim, { toValue: -1, duration: 150, useNativeDriver: true }),
        Animated.timing(bellAnim, { toValue: 0, duration: 150, useNativeDriver: true }),
      ]).start();
    }
  }, [state.conversations]);

  // Check for expired listings every 60 seconds
  useEffect(() => {
    dispatch({ type: "EXPIRE_LISTINGS" });
    const interval = setInterval(() => {
      dispatch({ type: "EXPIRE_LISTINGS" });
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  const filtered = state.listings.filter((l) => {
    if (l.isDeleted) return false;
    // Auto-filter expired listings from browse view
    if (new Date(l.expiresAt).getTime() < Date.now()) return false;
    const matchCat = activeCategory === "All" || l.category === activeCategory;
    const matchSearch =
      search.trim() === "" ||
      l.userName.toLowerCase().includes(search.toLowerCase()) ||
      l.title.toLowerCase().includes(search.toLowerCase()) ||
      l.location.toLowerCase().includes(search.toLowerCase());
    const matchLocation =
      locationFilter.trim() === "" ||
      l.location.toLowerCase().includes(locationFilter.toLowerCase());
    return matchCat && matchSearch && matchLocation;
  });

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.logo}>ALLURE</Text>
          <Text style={styles.tagline}>Meet. Connect. Ignite.</Text>
        </View>
        <Pressable
          onPress={() => router.push("/messages" as any)}
          style={({ pressed }) => [styles.iconBtn, pressed && { opacity: 0.7 }]}
        >
          <IconSymbol name="message.fill" size={18} color="#9A8F8F" />
        </Pressable>
      </View>

      {/* Centered filter icons */}
      <View style={styles.centeredIconsRow}>
        {/* Advanced Filters */}
        <Pressable
          onPress={() => router.push("/filters" as any)}
          style={({ pressed }) => [styles.iconBtn, pressed && { opacity: 0.7 }]}
        >
          <IconSymbol name="slider.horizontal.3" size={18} color="#9A8F8F" />
        </Pressable>
        {/* Notification Bell */}
        <Pressable
          onPress={() => { setHasUnreadNotif(false); router.push("/notifications" as any); }}
          style={({ pressed }) => [styles.iconBtn, pressed && { opacity: 0.7 }]}
        >
          <Animated.View style={{ transform: [{ rotate: bellAnim.interpolate({ inputRange: [-1, 0, 1], outputRange: ["-15deg", "0deg", "15deg"] }) }] }}>
            <IconSymbol name="bell.fill" size={18} color={hasUnreadNotif ? "#D42B2B" : "#9A8F8F"} />
          </Animated.View>
          {hasUnreadNotif && <View style={styles.notifDot} />}
        </Pressable>
        {/* Location filter */}
        <Pressable
          onPress={() => setShowLocationFilter((v) => !v)}
          style={({ pressed }) => [styles.locationBtn, showLocationFilter && styles.locationBtnActive, pressed && { opacity: 0.7 }]}
        >
          <IconSymbol name="location.fill" size={16} color={showLocationFilter ? "#D42B2B" : "#7A6F6F"} />
          <Text style={[styles.locationBtnText, showLocationFilter && { color: "#D42B2B" }]}>
            {locationFilter || "All Cities"}
          </Text>
        </Pressable>
      </View>

      {/* Location filter input */}
      {showLocationFilter && (
        <View style={styles.locationFilterRow}>
          <IconSymbol name="location.fill" size={14} color="#D42B2B" />
          <TextInput
            value={locationFilter}
            onChangeText={setLocationFilter}
            placeholder="Filter by city (e.g. Miami, NY...)"
            placeholderTextColor="#5A4A4A"
            style={styles.locationInput}
            returnKeyType="search"
            autoFocus
          />
          {locationFilter.length > 0 && (
            <Pressable onPress={() => setLocationFilter("")}>
              <IconSymbol name="xmark.circle.fill" size={16} color="#7A6F6F" />
            </Pressable>
          )}
        </View>
      )}

      {/* Search */}
      <View style={styles.searchRow}>
        <View style={styles.searchBox}>
          <IconSymbol name="magnifyingglass" size={16} color="#7A6F6F" />
          <TextInput
            value={search}
            onChangeText={setSearch}
            placeholder="Search by name, city, or keyword..."
            placeholderTextColor="#7A6F6F"
            style={styles.searchInput}
            returnKeyType="search"
          />
          {search.length > 0 && (
            <Pressable onPress={() => setSearch("")}>
              <IconSymbol name="xmark.circle.fill" size={16} color="#7A6F6F" />
            </Pressable>
          )}
        </View>
      </View>

      {/* Category Filters */}
      <FlatList
        data={CATEGORIES}
        horizontal
        showsHorizontalScrollIndicator={false}
        keyExtractor={(item) => item}
        contentContainerStyle={styles.categoryList}
        renderItem={({ item }) => (
          <Pressable
            onPress={() => setActiveCategory(item)}
            style={[styles.categoryBtn, activeCategory === item && styles.categoryBtnActive]}
          >
            <Text style={[styles.categoryBtnText, activeCategory === item && styles.categoryBtnTextActive]}>
              {item}
            </Text>
          </Pressable>
        )}
      />

      {/* Results count */}
      <View style={styles.resultsRow}>
        <Text style={styles.resultsText}>
          {filtered.length} {filtered.length === 1 ? "ad" : "ads"} available
          {locationFilter ? ` in ${locationFilter}` : ""}
        </Text>
      </View>

      {/* Listings */}
      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        numColumns={2}
        contentContainerStyle={styles.listContent}
        columnWrapperStyle={styles.columnWrapper}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyIcon}>🔍</Text>
            <Text style={styles.emptyText}>No ads found</Text>
            <Text style={styles.emptySubtext}>
              {locationFilter
                ? `No ads in "${locationFilter}". Try a different city.`
                : "Try a different category or search term"}
            </Text>
            {locationFilter && (
              <Pressable onPress={() => setLocationFilter("")} style={styles.clearLocationBtn}>
                <Text style={styles.clearLocationBtnText}>Clear Location Filter</Text>
              </Pressable>
            )}
          </View>
        }
        renderItem={({ item }) => (
          <ListingCard item={item} onPress={() => router.push(`/listing/${item.id}`)} />
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0A0A0A" },
  header: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 20, paddingBottom: 12, paddingTop: 8,
  },
  logo: { fontSize: 28, fontWeight: "900", color: "#D42B2B", letterSpacing: 6 },
  tagline: { fontSize: 11, color: "#7A6F6F", letterSpacing: 2, marginTop: 2 },
  iconBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: "#161618", borderWidth: 1, borderColor: "#2A1F1F",
    alignItems: "center", justifyContent: "center", position: "relative",
  },
  notifDot: {
    position: "absolute", top: 4, right: 4,
    width: 8, height: 8, borderRadius: 4, backgroundColor: "#D42B2B",
    borderWidth: 1.5, borderColor: "#0A0A0A",
  },
  locationBtn: {
    flexDirection: "row", alignItems: "center", gap: 6,
    backgroundColor: "#161618", borderRadius: 20, paddingHorizontal: 12, paddingVertical: 7,
    borderWidth: 1, borderColor: "#2A1F1F",
  },
  locationBtnActive: { borderColor: "#D42B2B", backgroundColor: "#1A0A0A" },
  locationBtnText: { color: "#7A6F6F", fontSize: 12, fontWeight: "600", maxWidth: 80 },
  centeredIconsRow: {
    flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 20,
    paddingHorizontal: 16, paddingVertical: 12, backgroundColor: "#0A0A0A",
  },
  locationFilterRow: {
    flexDirection: "row", alignItems: "center", gap: 8,
    marginHorizontal: 16, marginBottom: 8,
    backgroundColor: "#161618", borderRadius: 12, paddingHorizontal: 12, paddingVertical: 10,
    borderWidth: 1, borderColor: "#D42B2B",
  },
  locationInput: { flex: 1, color: "#F5F0F0", fontSize: 14 },
  searchRow: { paddingHorizontal: 16, marginBottom: 12 },
  searchBox: {
    flexDirection: "row", alignItems: "center", backgroundColor: "#161618",
    borderRadius: 12, paddingHorizontal: 12, paddingVertical: 10,
    borderWidth: 1, borderColor: "#2A1F1F", gap: 8,
  },
  searchInput: { flex: 1, color: "#F5F0F0", fontSize: 14 },
  categoryList: { paddingHorizontal: 16, paddingBottom: 12, gap: 8 },
  categoryBtn: {
    paddingHorizontal: 16, paddingVertical: 7, borderRadius: 20,
    backgroundColor: "#161618", borderWidth: 1, borderColor: "#2A1F1F", marginRight: 8,
  },
  categoryBtnActive: { backgroundColor: "#D42B2B", borderColor: "#D42B2B" },
  categoryBtnText: { color: "#7A6F6F", fontSize: 13, fontWeight: "600" },
  categoryBtnTextActive: { color: "#F5F0F0" },
  resultsRow: { paddingHorizontal: 16, marginBottom: 8 },
  resultsText: { color: "#5A4A4A", fontSize: 12 },
  listContent: { paddingHorizontal: 12, paddingBottom: 100 },
  columnWrapper: { gap: 10, marginBottom: 10 },
  card: {
    flex: 1, height: 240, borderRadius: 14, overflow: "hidden",
    backgroundColor: "#161618", borderWidth: 1, borderColor: "#2A1F1F",
  },
  featuredCard: {
    borderColor: "#D42B2B",
    shadowColor: "#D42B2B", shadowOpacity: 0.35, shadowRadius: 10,
    shadowOffset: { width: 0, height: 0 }, elevation: 6,
  },
  cardImage: { width: "100%", height: "100%", position: "absolute" },
  cardOverlay: { position: "absolute", bottom: 0, left: 0, right: 0, height: "65%" },
  featuredBadge: {
    position: "absolute", top: 8, left: 8, backgroundColor: "#D42B2B",
    borderRadius: 6, paddingHorizontal: 6, paddingVertical: 3,
  },
  featuredText: { color: "#F5F0F0", fontSize: 9, fontWeight: "800", letterSpacing: 1 },
  onlineDot: {
    position: "absolute", top: 10, right: 10, width: 10, height: 10,
    borderRadius: 5, backgroundColor: "#4CAF82", borderWidth: 1.5, borderColor: "#0A0A0A",
  },
  favBadge: {
    position: "absolute", top: 8, right: 8,
    backgroundColor: "rgba(212,43,43,0.85)", borderRadius: 10,
    width: 22, height: 22, alignItems: "center", justifyContent: "center",
  },
  expiryBadge: {
    position: "absolute", bottom: 70, left: 8,
    backgroundColor: "rgba(20,10,10,0.85)", borderRadius: 6,
    paddingHorizontal: 6, paddingVertical: 3, borderWidth: 1, borderColor: "#3A2A2A",
  },
  expiryBadgeUrgent: { borderColor: "#D42B2B" },
  expiryBadgeText: { color: "#9A8F8F", fontSize: 9, fontWeight: "700" },
  cardInfo: {
    position: "absolute", bottom: 0, left: 0, right: 0,
    padding: 10, backgroundColor: "rgba(10,10,10,0.82)",
  },
  cardName: { color: "#F5F0F0", fontSize: 14, fontWeight: "700" },
  reviewCount: { color: "#7A6F6F", fontSize: 10 },
  cardLocation: { color: "#7A6F6F", fontSize: 10, flex: 1 },
  categoryPill: { backgroundColor: "#2A1010", borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2 },
  categoryPillText: { color: "#D42B2B", fontSize: 9, fontWeight: "700" },
  verifiedBadge: {
    backgroundColor: "#D42B2B", borderRadius: 8,
    width: 14, height: 14, alignItems: "center", justifyContent: "center",
  },
  verifiedText: { color: "#F5F0F0", fontSize: 8, fontWeight: "900" },
  emptyState: { alignItems: "center", paddingTop: 80, gap: 8 },
  emptyIcon: { fontSize: 40 },
  emptyText: { color: "#F5F0F0", fontSize: 18, fontWeight: "700" },
  emptySubtext: { color: "#7A6F6F", fontSize: 13, textAlign: "center", paddingHorizontal: 20 },
  clearLocationBtn: {
    marginTop: 8, paddingHorizontal: 20, paddingVertical: 10,
    borderRadius: 20, borderWidth: 1, borderColor: "#D42B2B",
  },
  clearLocationBtnText: { color: "#D42B2B", fontWeight: "600", fontSize: 14 },
});
