import * as Notifications from "expo-notifications";
import { SchedulableTriggerInputTypes } from "expo-notifications";
import { Platform } from "react-native";

// Configure how notifications appear when app is in foreground
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

export async function registerForNotificationsAsync(): Promise<string | null> {
  if (Platform.OS === "web") return null;

  // Set up Android channel
  if (Platform.OS === "android") {
    await Notifications.setNotificationChannelAsync("messages", {
      name: "Messages",
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: "#D42B2B",
      sound: "default",
    });
    await Notifications.setNotificationChannelAsync("listings", {
      name: "Listings",
      importance: Notifications.AndroidImportance.DEFAULT,
      lightColor: "#D42B2B",
    });
  }

  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;

  if (existingStatus !== "granted") {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }

  if (finalStatus !== "granted") {
    return null;
  }

  return "granted";
}

export async function scheduleMessageNotification(
  senderName: string,
  messageText: string,
  conversationId: string
) {
  if (Platform.OS === "web") return;
  await Notifications.scheduleNotificationAsync({
    content: {
      title: `New message from ${senderName}`,
      body: messageText,
      data: { screen: "chat", conversationId },
      sound: "default",
      badge: 1,
    },
    trigger: null, // immediate
  });
}

export async function scheduleListingExpiryNotification(
  listingTitle: string,
  expiresAt: string
) {
  if (Platform.OS === "web") return;
  const expiryDate = new Date(expiresAt);
  const warningDate = new Date(expiryDate.getTime() - 2 * 3600000); // 2 hours before
  const now = new Date();

  if (warningDate > now) {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: "⏰ Listing Expiring Soon",
        body: `Your listing "${listingTitle}" expires in 2 hours. Renew it to keep it live!`,
        data: { screen: "profile" },
        sound: "default",
      },
      trigger: { type: SchedulableTriggerInputTypes.DATE, date: warningDate },
    });
  }
}

export async function cancelAllNotifications() {
  await Notifications.cancelAllScheduledNotificationsAsync();
}
