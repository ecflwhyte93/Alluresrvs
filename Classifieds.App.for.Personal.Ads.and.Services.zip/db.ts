import { and, desc, eq, gt } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, payments, conversations, messages, InsertPayment, InsertMessage } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ── Payments ──────────────────────────────────────────────────────────────────

export async function createPayment(data: InsertPayment) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(payments).values(data);
  return (result as any)[0].insertId as number;
}

export async function getPaymentById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(payments).where(eq(payments.id, id)).limit(1);
  return result[0];
}

export async function updatePaymentStatus(
  id: number,
  status: "pending" | "succeeded" | "failed" | "refunded",
  stripePaymentIntentId?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const updateData: Record<string, unknown> = { status };
  if (stripePaymentIntentId) updateData.stripePaymentIntentId = stripePaymentIntentId;
  await db.update(payments).set(updateData).where(eq(payments.id, id));
}

export async function getUserPayments(userId: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(payments)
    .where(and(eq(payments.userId, userId), eq(payments.status, "succeeded")))
    .orderBy(desc(payments.createdAt))
    .limit(20);
}

// ── Conversations ─────────────────────────────────────────────────────────────

export async function getOrCreateConversation(
  id: string,
  userId: string,
  advertiserId: string,
  listingId: string,
  listingTitle: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const existing = await db.select().from(conversations).where(eq(conversations.id, id)).limit(1);
  if (existing[0]) return existing[0];
  await db.insert(conversations).values({ id, userId, advertiserId, listingId, listingTitle });
  const created = await db.select().from(conversations).where(eq(conversations.id, id)).limit(1);
  return created[0];
}

export async function getUserConversations(userId: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(conversations)
    .where(eq(conversations.userId, userId))
    .orderBy(desc(conversations.updatedAt));
}

export async function completeConversation(id: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(conversations).set({ isCompleted: true }).where(eq(conversations.id, id));
}

// ── Messages ──────────────────────────────────────────────────────────────────

export async function sendMessage(data: InsertMessage) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(messages).values(data);
  await db.update(conversations).set({ updatedAt: new Date() }).where(eq(conversations.id, data.conversationId));
  return (result as any)[0].insertId as number;
}

export async function getMessages(conversationId: string, afterId?: number) {
  const db = await getDb();
  if (!db) return [];
  const conditions = afterId
    ? and(eq(messages.conversationId, conversationId), gt(messages.id, afterId))
    : eq(messages.conversationId, conversationId);
  return db.select().from(messages).where(conditions).orderBy(messages.id).limit(200);
}

export async function markMessagesRead(conversationId: string) {
  const db = await getDb();
  if (!db) return;
  await db.update(messages).set({ isRead: true })
    .where(and(eq(messages.conversationId, conversationId), eq(messages.isRead, false)));
}

export async function getUnreadCount(conversationId: string, senderId: string) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select().from(messages)
    .where(and(eq(messages.conversationId, conversationId), eq(messages.isRead, false)));
  return result.filter(m => m.senderId !== senderId).length;
}
