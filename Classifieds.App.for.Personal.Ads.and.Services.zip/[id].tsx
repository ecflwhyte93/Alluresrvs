import { useLocalSearchParams, useRouter } from "expo-router";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { IconSymbol } from "@/components/ui/icon-symbol";
import { useAppStore } from "@/lib/store";
import { trpc } from "@/lib/trpc";

type BackendMessage = {
  id: number;
  conversationId: string;
  senderId: string;
  text: string;
  isRead: boolean;
  createdAt: Date;
};

type DisplayMessage = {
  id: string;
  senderId: string;
  text: string;
  timestamp: string;
  isLocal?: boolean;
};

function timeStr(iso: string | Date) {
  return new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

export default function ChatScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { state, dispatch } = useAppStore();
  const [text, setText] = useState("");
  const [messages, setMessages] = useState<DisplayMessage[]>([]);
  const [isInitialized, setIsInitialized] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const lastMsgIdRef = useRef<number | undefined>(undefined);
  const listRef = useRef<FlatList>(null);
  const pollIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const conv = state.conversations.find((c) => c.id === id);

  const sendMutation = trpc.messages.send.useMutation();
  const markReadMutation = trpc.messages.markRead.useMutation();
  const completeMutation = trpc.messages.complete.useMutation();

  const getAllQuery = trpc.messages.getAll.useQuery(
    { conversationId: id ?? "" },
    { enabled: !!id, refetchOnMount: true }
  );
  const pollQuery = trpc.messages.poll.useQuery(
    { conversationId: id ?? "", afterId: lastMsgIdRef.current },
    { enabled: false }
  );

  useEffect(() => {
    if (!id) return;
    dispatch({ type: "MARK_READ", payload: id });
    markReadMutation.mutate({ conversationId: id });
  }, [id]);

  useEffect(() => {
    if (!getAllQuery.data || isInitialized) return;
    const backendMsgs = getAllQuery.data as BackendMessage[];
    if (backendMsgs.length > 0) {
      setMessages(backendMsgs.map((m) => ({
        id: String(m.id), senderId: m.senderId, text: m.text,
        timestamp: new Date(m.createdAt).toISOString(),
      })));
      lastMsgIdRef.current = backendMsgs[backendMsgs.length - 1].id;
    } else {
      const localMsgs = conv?.messages ?? [];
      setMessages(localMsgs.map((m) => ({ id: m.id, senderId: m.senderId, text: m.text, timestamp: m.timestamp, isLocal: true })));
    }
    setIsInitialized(true);
  }, [getAllQuery.data, isInitialized]);

  useEffect(() => {
    if (!id || !isInitialized) return;
    const poll = async () => {
      try {
        const result = await pollQuery.refetch();
        const newMsgs = result.data as BackendMessage[] | undefined;
        if (newMsgs && newMsgs.length > 0) {
          setMessages((prev) => {
            const existingIds = new Set(prev.map((m) => m.id));
            const fresh = newMsgs
              .filter((m) => !existingIds.has(String(m.id)))
              .map((m) => ({ id: String(m.id), senderId: m.senderId, text: m.text, timestamp: new Date(m.createdAt).toISOString() }));
            return fresh.length > 0 ? [...prev, ...fresh] : prev;
          });
          lastMsgIdRef.current = newMsgs[newMsgs.length - 1].id;
        }
      } catch { /* silent */ }
    };
    pollIntervalRef.current = setInterval(poll, 3000);
    return () => { if (pollIntervalRef.current) clearInterval(pollIntervalRef.current); };
  }, [id, isInitialized]);

  useEffect(() => {
    if (messages.length > 0) setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 100);
  }, [messages.length]);

  if (!conv) {
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <Pressable onPress={() => router.back()} style={{ margin: 20, width: 36, height: 36, borderRadius: 18, backgroundColor: "#161618", alignItems: "center", justifyContent: "center" }}>
          <IconSymbol name="chevron.left" size={20} color="#F5F0F0" />
        </Pressable>
        <Text style={{ color: "#F5F0F0", textAlign: "center", marginTop: 40 }}>Conversation not found.</Text>
      </View>
    );
  }

  const handleSend = async () => {
    const trimmed = text.trim();
    if (!trimmed || isSending) return;
    const optimisticId = `opt_${Date.now()}`;
    setMessages((prev) => [...prev, { id: optimisticId, senderId: "me", text: trimmed, timestamp: new Date().toISOString(), isLocal: true }]);
    setText("");
    setIsSending(true);
    dispatch({ type: "SEND_MESSAGE", payload: { conversationId: conv.id, text: trimmed } });
    try {
      const result = await sendMutation.mutateAsync({ conversationId: conv.id, senderId: "me", text: trimmed });
      setMessages((prev) => prev.map((m) => m.id === optimisticId ? { ...m, id: String(result.id), isLocal: false } : m));
      lastMsgIdRef.current = result.id;
    } catch { /* keep optimistic */ } finally { setIsSending(false); }
  };

  const handleComplete = () => {
    Alert.alert(
      "Mark as Complete",
      "Mark this conversation as complete? You'll be able to leave a rating.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Complete",
          onPress: async () => {
            dispatch({ type: "COMPLETE_CONVERSATION", payload: conv.id });
            try { await completeMutation.mutateAsync({ conversationId: conv.id }); } catch { /* local fallback */ }
            router.push({ pathname: "/rate/[conversationId]", params: { conversationId: conv.id } });
          },
        },
      ]
    );
  };

  return (
    <KeyboardAvoidingView
      style={[styles.container, { paddingTop: insets.top }]}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      keyboardVerticalOffset={0}
    >
      {/* Header */}
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <IconSymbol name="chevron.left" size={22} color="#F5F0F0" />
        </Pressable>
        <Image source={{ uri: conv.participantAvatar }} style={styles.headerAvatar} />
        <View style={{ flex: 1 }}>
          <Text style={styles.headerName}>{conv.participantName}</Text>
          <Text style={styles.headerListing} numberOfLines={1}>Re: {conv.listingTitle}</Text>
        </View>
        {!conv.isCompleted && (
          <Pressable onPress={handleComplete} style={styles.completeBtn}>
            <Text style={styles.completeBtnText}>Complete</Text>
          </Pressable>
        )}
        {conv.isCompleted && !conv.myRatingGiven && (
          <Pressable
            onPress={() => router.push({ pathname: "/rate/[conversationId]", params: { conversationId: conv.id } })}
            style={styles.rateBtn}
          >
            <Text style={styles.rateBtnText}>Rate ★</Text>
          </Pressable>
        )}
      </View>

      {/* Live indicator */}
      <View style={styles.liveBar}>
        <View style={styles.liveDot} />
        <Text style={styles.liveText}>Live · Updates every 3s</Text>
      </View>

      {/* Messages */}
      {!isInitialized ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", gap: 12 }}>
          <ActivityIndicator color="#D42B2B" size="large" />
          <Text style={{ color: "#7A6F6F", fontSize: 13 }}>Loading messages...</Text>
        </View>
      ) : (
        <FlatList
          ref={listRef}
          data={messages}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.msgList}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.emptyChat}>
              <Text style={styles.emptyChatText}>Say hello to {conv.participantName}! 👋</Text>
            </View>
          }
          renderItem={({ item }) => {
            const isMe = item.senderId === "me";
            return (
              <View style={[styles.bubbleRow, isMe && styles.bubbleRowMe]}>
                {!isMe && (
                  <Image source={{ uri: conv.participantAvatar }} style={styles.bubbleAvatar} />
                )}
                <View style={[styles.bubble, isMe ? styles.bubbleMe : styles.bubbleThem]}>
                  <Text style={[styles.bubbleText, isMe && styles.bubbleTextMe]}>{item.text}</Text>
                  <Text style={[styles.bubbleTime, isMe && styles.bubbleTimeMe]}>{timeStr(item.timestamp)}</Text>
                </View>
              </View>
            );
          }}
        />
      )}

      {/* Completed banner */}
      {conv.isCompleted && (
        <View style={styles.completedBanner}>
          <Text style={styles.completedBannerText}>
            ✓ Conversation completed
            {conv.myRatingGiven ? " · Rating submitted" : " · Don't forget to leave a rating!"}
          </Text>
        </View>
      )}

      {/* Input */}
      {!conv.isCompleted && (
        <View style={[styles.inputBar, { paddingBottom: insets.bottom + 8 }]}>
          <TextInput
            value={text}
            onChangeText={setText}
            placeholder={`Message ${conv.participantName}...`}
            placeholderTextColor="#7A6F6F"
            style={styles.input}
            returnKeyType="send"
            onSubmitEditing={handleSend}
            multiline
          />
          <Pressable
            onPress={handleSend}
            disabled={!text.trim() || isSending}
            style={[styles.sendBtn, (!text.trim() || isSending) && styles.sendBtnDisabled]}
          >
            {isSending ? <ActivityIndicator color="#F5F0F0" size="small" /> : <IconSymbol name="paperplane.fill" size={18} color="#F5F0F0" />}
          </Pressable>
        </View>
      )}
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0A0A0A" },
  header: {
    flexDirection: "row", alignItems: "center", gap: 10,
    paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: "#2A1F1F",
    backgroundColor: "#0F0F0F",
  },
  backBtn: { padding: 4 },
  headerAvatar: { width: 38, height: 38, borderRadius: 19, borderWidth: 2, borderColor: "#D42B2B" },
  headerName: { color: "#F5F0F0", fontSize: 15, fontWeight: "700" },
  headerListing: { color: "#7A6F6F", fontSize: 11, marginTop: 1 },
  completeBtn: {
    backgroundColor: "#161618", borderRadius: 10,
    paddingHorizontal: 10, paddingVertical: 6,
    borderWidth: 1, borderColor: "#2A1F1F",
  },
  completeBtnText: { color: "#7A6F6F", fontSize: 11, fontWeight: "600" },
  rateBtn: {
    backgroundColor: "#2A1010", borderRadius: 10,
    paddingHorizontal: 10, paddingVertical: 6,
    borderWidth: 1, borderColor: "#D42B2B",
  },
  rateBtnText: { color: "#D42B2B", fontSize: 11, fontWeight: "700" },
  msgList: { paddingHorizontal: 16, paddingVertical: 16, gap: 12, paddingBottom: 20 },
  bubbleRow: { flexDirection: "row", alignItems: "flex-end", gap: 8 },
  bubbleRowMe: { justifyContent: "flex-end" },
  bubbleAvatar: { width: 28, height: 28, borderRadius: 14 },
  bubble: {
    maxWidth: "75%", borderRadius: 16, padding: 12,
    backgroundColor: "#161618", borderWidth: 1, borderColor: "#2A1F1F",
  },
  bubbleMe: {
    backgroundColor: "#D42B2B", borderColor: "#D42B2B",
    borderBottomRightRadius: 4,
  },
  bubbleThem: { borderBottomLeftRadius: 4 },
  bubbleText: { color: "#F5F0F0", fontSize: 14, lineHeight: 20 },
  bubbleTextMe: { color: "#F5F0F0" },
  bubbleTime: { color: "#7A6F6F", fontSize: 10, marginTop: 4, textAlign: "right" },
  bubbleTimeMe: { color: "rgba(245,240,240,0.7)" },
  emptyChat: { alignItems: "center", paddingTop: 60 },
  emptyChatText: { color: "#7A6F6F", fontSize: 14 },
  completedBanner: {
    backgroundColor: "#1A1010", paddingVertical: 10, paddingHorizontal: 16,
    borderTopWidth: 1, borderTopColor: "#2A1F1F",
  },
  completedBannerText: { color: "#D42B2B", fontSize: 12, textAlign: "center", fontWeight: "600" },
  inputBar: {
    flexDirection: "row", alignItems: "flex-end", gap: 10,
    paddingHorizontal: 16, paddingTop: 10,
    backgroundColor: "#0F0F0F", borderTopWidth: 1, borderTopColor: "#2A1F1F",
  },
  input: {
    flex: 1, backgroundColor: "#161618", borderRadius: 22,
    paddingHorizontal: 16, paddingVertical: 10,
    color: "#F5F0F0", fontSize: 14, maxHeight: 100,
    borderWidth: 1, borderColor: "#2A1F1F",
  },
  sendBtn: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: "#D42B2B", alignItems: "center", justifyContent: "center",
  },
  sendBtnDisabled: { opacity: 0.4 },
  liveBar: {
    flexDirection: "row", alignItems: "center", gap: 6,
    paddingHorizontal: 16, paddingVertical: 6,
    backgroundColor: "#0F0F0F", borderBottomWidth: 1, borderBottomColor: "#1A1A1A",
  },
  liveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: "#4CAF82" },
  liveText: { color: "#4A3F3F", fontSize: 10 },
});
